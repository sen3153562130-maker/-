/* ===== 全站公共脚本：API 封装、i18n、导航、语言联动、演示色 ===== */

const TOKEN_KEY = 'silu-token';
const USER_KEY = 'silu-user';

async function api(path, options = {}) {
  const token = localStorage.getItem(TOKEN_KEY);
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const resp = await fetch(path, { ...options, headers });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(tError(data.error) || t('error.request', { status: resp.status }));
  return data;
}

function currentUser() {
  try { return JSON.parse(localStorage.getItem(USER_KEY)) || null; }
  catch { return null; }
}
function isLoggedIn() { return !!currentUser(); }
function setSession(token, user) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}
function clearSession() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}
async function logout() {
  try { await api('/api/auth/logout', { method: 'POST' }); } catch { /* 忽略本地登出失败 */ }
  clearSession();
}

async function restoreSession() {
  if (!currentUser()) return;
  try {
    const r = await api('/api/auth/me');
    const token = localStorage.getItem(TOKEN_KEY);
    setSession(token, r.user);
  } catch { clearSession(); }
}

const SUPPORTED_LANGS = ['zh', 'en', 'id', 'ms', 'th'];
const LANG_LABEL = { zh: '中文', en: 'EN', id: 'ID', ms: 'MS', th: 'TH' };

/* ===== 五语 UI 文案字典 ===== */
const I18N = {
  zh: {
    'nav.library': '数字资产库', 'nav.exhibit': '文物拆装演示', 'nav.studio': '创作工坊',
    'nav.community': '共创社区', 'nav.account': '注册/登录',
    'search.placeholder': '搜索文物 / 技艺 / 传承人 / 关键词…', 'search.button': '搜索',
    'filter.country': '来源国家 / 地区', 'filter.type': '资产类型', 'filter.status': '审核状态',
    'result.count': '共 {n} 件资产',
    'status.approved': '已通过专家审核', 'status.pending': '待审核', 'status.machine': '机器生成待核验',
    'tab.overall': '① 整体三维视图', 'tab.explode': '② 结构拆装',
    'exhibit.studioModels': '工坊模型', 'exhibit.studioSummary': '来自创作工坊的模型。', 'exhibit.noStudioModel': '工坊暂无生成模型。',
    'tab.craft': '③ 技艺演示', 'tab.caption': '④ 多语展签',
    'caption.translate': 'AI 翻译为英 / 印尼 / 马来 / 泰',
    'video.related': '相关视频', 'video.none': '暂无相关影像资料', 'video.searchBtn': '检索相关视频',
    'studio.title': '创作工坊', 'studio.sub': '上传文物或工艺品本地照片，由 Tripo AI 重建 3D 模型；支持单图生 3D、四视图生 3D 与单图生成参考图。',
    'studio.modeling': '图片生成 3D（Tripo）', 'studio.modeSingle': '单张图片', 'studio.modeMulti': '四视图', 'studio.modeMV': '单图生成参考图',
    'studio.viewFront': '正面', 'studio.viewLeft': '左面', 'studio.viewBack': '背面', 'studio.viewRight': '右面',
    'studio.multiHint': '正面必传，至少 2 张；请为同一物体、一致光照下的不同视角。',
    'studio.generate': '生成 3D 模型', 'studio.genMV': '生成参考图',
    'studio.mvMock': '参考图为演示占位（方舟图像模型未开通）。',
    'studio.preview': '3D 预览窗口', 'studio.previewHint': '生成完成后在此预览模型；也可在下方检索相关影像',
    'studio.exportModel': '导出模型 (.glb)', 'studio.saveImage': '保存图片',
    'exhibit.segment': 'Tripo 智能拆解', 'exhibit.segmenting': '拆解中…',
    'exhibit.segmentDone': '智能拆解完成，可在预览中点选、合并部件', 'exhibit.segmentFailed': '智能拆解失败，请重试',
    'exhibit.restore': '还原组件位置', 'exhibit.partHint': '点击预览中的部件进行选择，拖动部件上的箭头即可移动它；依次点击两个部件可将其合并；点击「还原」复位全部部件。',
    'exhibit.partSelected': '已选中：{name}', 'exhibit.partMerged': '已合并：{a} + {b}', 'exhibit.partEmpty': '尚未选择部件',
    'studio.upload3d': '上传已有 3D 文件（.glb / .gltf）',
    'studio.vision': '图片识别分析（豆包视觉）', 'studio.visionBtn': '识别图片',
    'community.showcase': '作品展映', 'community.review': '审核队列（专家视角）',
    'community.forumSub': '登录后可在论坛发言、附上创作工坊生成的模型，并查看其他用户的分享。',
    'community.loginToPost': '登录后即可发帖与附上模型。',
    'community.postPlaceholder': '分享你的创作思路、参考来源或对这件作品的看法…',
    'community.attachModel': '附上工坊模型（可选）', 'community.noModel': '不附模型',
    'community.publish': '发布', 'community.noPost': '还没有帖子，来发第一帖吧。', 'community.emptyPost': '发言内容不能为空',
    'community.expertOnly': '审核队列仅对已通过审核的专家开放。请先以专家身份注册并通过审核。',
    'review.approve': '通过上架', 'review.reject': '退回修改',
    'account.join': '加入平台', 'account.sub': '注册独立账号后，可在工坊生成模型、在社区论坛发言并附上自己的作品。',
    'account.expert': '专家', 'account.creator': '创作者',
    'account.profile': '我的账号', 'account.logout': '退出登录', 'account.login': '登录', 'account.register': '注册',
    'account.username': '用户名', 'account.password': '密码', 'account.name': '姓名 / 机构名称',
    'account.country': '国家 / 地区', 'account.role': '角色', 'account.loginBtn': '登录', 'account.registerBtn': '提交注册',
    'account.loginSuccess': '登录成功。', 'account.registerSuccess': '注册成功，已自动登录。',
    'account.countryPh': '如：中国 · 马来西亚 · 印度尼西亚 · 澳大利亚',
    'brand.subtitle': '中国—东盟多语种文化遗产共创平台', 'footer.text': '丝路遗珍 · 数字文化遗产平台 — 原型 v0.1',
    'index.title': '数字非遗资产库', 'index.sub': '三维模型 · 高清图文 · 影像纪录 · 拆装演示 · 技艺演示，每一件都是可复用的完整数字资产包。',
    'index.empty': '没有符合条件的资产，试试调整筛选或关键词。',
    'filter.all': '全部', 'filter.any': '不限',
    'cat.ceramic': '陶瓷', 'cat.textile': '织锦', 'cat.wood': '木作', 'cat.folk': '民俗',
    'country.cn': '中国', 'country.id': '印度尼西亚', 'country.my': '马来西亚', 'country.au': '澳大利亚',
    'type.model': '3D数字模型', 'type.assembly': '文物拆装演示', 'type.craft': '非遗技艺演示', 'type.text': '图文', 'type.label': '多语种展签',
    'exhibit.notFound': '未找到对应资产。',
    'overall.hintParts': '点击任意部位查看说明', 'overall.clickExpand': '点击展开', 'overall.unit': '整体器型',
    'explode.noLayers': '该资产暂无分层结构数据，可在创作工坊中通过模型分层后生成分层拆装视图。',
    'explode.layerHint': '滑动滑块逐层展开 / 合并，理解结构与工艺顺序。', 'explode.layer': '层 {n}',
    'exhibit.segmentDesc': '由 Tripo AI 将模型自动切分为可拆装部件。',
    'viewer.modelHint': '3D 模型 · 可旋转 / 缩放 · 点击部件', 'viewer.placeholderHint': '占位器型 · 接入 Tripo GLB 后显示真实模型',
    'viewer.placeholderCube': '3D 预览区', 'viewer.hintBase': '可 360° 旋转 · 缩放 · 测量（接入真实 GLB 模型后加载）', 'viewer.partName': '部件 {n}',
    'studio.submitting': '任务提交中…', 'studio.queued': '任务 {id} 排队中…',
    'studio.modeling': '建模中… {status} {progress}', 'studio.modelDone': '建模完成。',
    'studio.modelMock': '建模完成（演示占位，Tripo 出模后返回 GLB 地址）', 'studio.modelFailed': '建模失败，请重试。',
    'studio.queryFailed': '任务查询失败，请刷新后重试：{msg}',
    'studio.selectPhoto': '请选择一张文物 / 工艺品照片', 'studio.selectViewPhoto': '请选择一张用于生成视图的照片',
    'studio.needFront': '必须提供正面视图', 'studio.needTwo': '至少需要 2 张有效视图图片',
    'studio.arkSubmitting': '提交方舟图像模型…', 'studio.viewDone': '视图生成完成。',
    'studio.viewUnavailable': '视图暂不可用：{msg}', 'studio.viewPlaceholder': '演示占位，方舟返回视图地址后显示',
    'studio.imageSaveFailed': '图片保存失败：{msg}', 'studio.exportFailed': '导出失败：{msg}', 'studio.submitFailed': '提交失败：{msg}',
    'studio.visionSelect': '请先选择图片。', 'studio.visionRunning': '识别中…', 'studio.visionFailed': '识别失败：{msg}',
    'studio.videoSelect': '请先选择图片，再检索相关视频。', 'studio.videoFound': '已检索到相关影像。', 'studio.videoFailed': '视频检索失败：{msg}',
    'studio.local3d': '已选择本地 3D 文件：{name}（原型仅登记文件名）', 'studio.fourViewModel': '四视图模型',
    'error.request': '请求失败 HTTP {status}', 'error.download': '下载失败 HTTP {status}',
    'error.usernameRequired': '请输入用户名', 'error.usernameTaken': '用户名已被占用', 'error.passwordShort': '密码至少 6 位', 'error.badCredentials': '用户名或密码错误', 'error.unauthorized': '请先登录后发言',
  },
  en: {
    'nav.library': 'Digital Archive', 'nav.exhibit': 'Object & Craft Demo', 'nav.studio': 'Creation Studio',
    'nav.community': 'Co-creation Community', 'nav.account': 'Sign Up / Login',
    'search.placeholder': 'Search heritage / craft / artisan…', 'search.button': 'Search',
    'filter.country': 'Origin Country / Region', 'filter.type': 'Asset Type', 'filter.status': 'Review Status',
    'result.count': '{n} assets',
    'status.approved': 'Expert-approved', 'status.pending': 'Pending Review', 'status.machine': 'AI-generated, pending verification',
    'tab.overall': '① Overall 3D View', 'tab.explode': '② Disassembly',
    'exhibit.studioModels': 'Studio Models', 'exhibit.studioSummary': 'A model generated in the studio.', 'exhibit.noStudioModel': 'No models generated in the studio yet.',
    'tab.craft': '③ Craft Demonstration', 'tab.caption': '④ Multilingual Label',
    'caption.translate': 'Translate to EN / ID / MS / TH',
    'video.related': 'Related Videos', 'video.none': 'No related video available', 'video.searchBtn': 'Search Related Video',
    'studio.title': 'Creation Studio', 'studio.sub': 'Upload local photos of an artifact or craft; Tripo AI rebuilds a 3D model. Single image, four views, or image-to-multiview.',
    'studio.modeling': 'Image to 3D (Tripo)', 'studio.modeSingle': 'Single Image', 'studio.modeMulti': 'Four Views', 'studio.modeMV': 'Reference View',
    'studio.viewFront': 'Front', 'studio.viewLeft': 'Left', 'studio.viewBack': 'Back', 'studio.viewRight': 'Right',
    'studio.multiHint': 'Front is required; at least 2 views. Same object under consistent lighting.',
    'studio.generate': 'Generate 3D Model', 'studio.genMV': 'Generate Reference',
    'studio.mvMock': 'The reference image is a placeholder (Ark image model not activated).',
    'studio.preview': '3D Preview', 'studio.previewHint': 'Preview the model here when ready; related footage can be searched below',
    'studio.exportModel': 'Export Model (.glb)', 'studio.saveImage': 'Save Image',
    'exhibit.segment': 'AI Segmentation (Tripo)', 'exhibit.segmenting': 'Segmenting…',
    'exhibit.segmentDone': 'Segmentation done — click parts in the preview to select or merge them', 'exhibit.segmentFailed': 'Segmentation failed, please retry',
    'exhibit.restore': 'Restore Parts', 'exhibit.partHint': 'Click a part to select it; drag its arrows to move it; click a second part to merge the two; click Restore to reset all parts.',
    'exhibit.partSelected': 'Selected: {name}', 'exhibit.partMerged': 'Merged: {a} + {b}', 'exhibit.partEmpty': 'No part selected',
    'studio.upload3d': 'Upload an existing 3D file (.glb / .gltf)',
    'studio.vision': 'Image Analysis (Doubao Vision)', 'studio.visionBtn': 'Analyze Image',
    'community.showcase': 'Showcase', 'community.review': 'Review Queue (Expert)',
    'community.forumSub': 'Log in to post in the forum, attach models generated in the studio, and view others’ shares.',
    'community.loginToPost': 'Log in to post and attach a model.',
    'community.postPlaceholder': 'Share your ideas, references or thoughts on the work…',
    'community.attachModel': 'Attach a studio model (optional)', 'community.noModel': 'No model attached',
    'community.publish': 'Post', 'community.noPost': 'No posts yet — be the first to share.', 'community.emptyPost': 'Content cannot be empty',
    'community.expertOnly': 'The review queue is open only to approved experts. Please register as an expert and get approved first.',
    'review.approve': 'Approve & Publish', 'review.reject': 'Request Revision',
    'account.join': 'Join the Platform', 'account.sub': 'Create an independent account to generate models in the studio, post in the forum and attach your works.',
    'account.expert': 'Expert', 'account.creator': 'Creator',
    'account.profile': 'My Account', 'account.logout': 'Log Out', 'account.login': 'Login', 'account.register': 'Register',
    'account.username': 'Username', 'account.password': 'Password', 'account.name': 'Name / Organization',
    'account.country': 'Country / Region', 'account.role': 'Role', 'account.loginBtn': 'Login', 'account.registerBtn': 'Register',
    'account.loginSuccess': 'Logged in.', 'account.registerSuccess': 'Registered, signed in automatically.',
    'account.countryPh': 'e.g. China · Malaysia · Indonesia · Australia',
    'brand.subtitle': 'China–ASEAN multilingual cultural heritage co-creation platform', 'footer.text': 'Silu Heritage · Digital Cultural Heritage Platform — Prototype v0.1',
    'index.title': 'Digital Heritage Archive', 'index.sub': '3D models · HD media · documentary footage · disassembly demos · craft demos — each a reusable digital asset package.',
    'index.empty': 'No assets match your filters. Try adjusting keywords or filters.',
    'filter.all': 'All', 'filter.any': 'Any',
    'cat.ceramic': 'Ceramics', 'cat.textile': 'Textiles', 'cat.wood': 'Woodwork', 'cat.folk': 'Folk',
    'country.cn': 'China', 'country.id': 'Indonesia', 'country.my': 'Malaysia', 'country.au': 'Australia',
    'type.model': '3D Model', 'type.assembly': 'Disassembly Demo', 'type.craft': 'Craft Demo', 'type.text': 'Article & Media', 'type.label': 'Multilingual Label',
    'exhibit.notFound': 'Asset not found.',
    'overall.hintParts': 'Click a part to view its description', 'overall.clickExpand': 'Click to expand', 'overall.unit': 'Overall form',
    'explode.noLayers': 'No layered structure data for this asset. Layer it in the studio to build a disassembly view.',
    'explode.layerHint': 'Drag the slider to expand / assemble layers and understand structure and craft order.', 'explode.layer': 'Layer {n}',
    'exhibit.segmentDesc': 'Tripo AI automatically splits the model into disassemblable parts.',
    'viewer.modelHint': '3D model · rotate / zoom · click parts', 'viewer.placeholderHint': 'Placeholder — real model appears after a Tripo GLB is loaded',
    'viewer.placeholderCube': '3D Preview', 'viewer.hintBase': 'Rotate 360° · Zoom · Measure (loads after a real GLB is connected)', 'viewer.partName': 'Part {n}',
    'studio.submitting': 'Submitting task…', 'studio.queued': 'Task {id} queued…',
    'studio.modeling': 'Building… {status} {progress}', 'studio.modelDone': 'Modeling done.',
    'studio.modelMock': 'Done (placeholder: Tripo returns the GLB URL after generation)', 'studio.modelFailed': 'Modeling failed, please retry.',
    'studio.queryFailed': 'Task query failed, please refresh and retry: {msg}',
    'studio.selectPhoto': 'Please choose a photo of an artifact or craft', 'studio.selectViewPhoto': 'Please choose a photo for the reference view',
    'studio.needFront': 'A front view is required', 'studio.needTwo': 'At least 2 valid view images are required',
    'studio.arkSubmitting': 'Submitting to Ark image model…', 'studio.viewDone': 'Reference view generated.',
    'studio.viewUnavailable': 'View unavailable: {msg}', 'studio.viewPlaceholder': 'Placeholder — appears after Ark returns the view URL',
    'studio.imageSaveFailed': 'Image save failed: {msg}', 'studio.exportFailed': 'Export failed: {msg}', 'studio.submitFailed': 'Submission failed: {msg}',
    'studio.visionSelect': 'Please select an image first.', 'studio.visionRunning': 'Analyzing…', 'studio.visionFailed': 'Analysis failed: {msg}',
    'studio.videoSelect': 'Select an image before searching related video.', 'studio.videoFound': 'Related footage found.', 'studio.videoFailed': 'Video search failed: {msg}',
    'studio.local3d': 'Local 3D file selected: {name} (prototype only records the filename)', 'studio.fourViewModel': 'Four-view model',
    'error.request': 'Request failed HTTP {status}', 'error.download': 'Download failed HTTP {status}',
    'error.usernameRequired': 'Please enter a username', 'error.usernameTaken': 'Username already taken', 'error.passwordShort': 'Password must be at least 6 characters', 'error.badCredentials': 'Wrong username or password', 'error.unauthorized': 'Please log in to post',
  },
  id: {
    'nav.library': 'Arsip Digital', 'nav.exhibit': 'Demo Objek & Keterampilan', 'nav.studio': 'Studio Kreatif',
    'nav.community': 'Komunitas Kolaborasi', 'nav.account': 'Daftar / Masuk',
    'search.placeholder': 'Cari warisan / kerajinan / perajin…', 'search.button': 'Cari',
    'filter.country': 'Negara / Asal Region', 'filter.type': 'Jenis Aset', 'filter.status': 'Status Review',
    'result.count': '{n} aset',
    'status.approved': 'Disetujui Pakar', 'status.pending': 'Menunggu Review', 'status.machine': 'Hasil AI menunggu verifikasi',
    'tab.overall': '① Tampilan 3D Utuh', 'tab.explode': '② Pembongkaran',
    'exhibit.studioModels': 'Model Studio', 'exhibit.studioSummary': 'Model yang dibuat di studio.', 'exhibit.noStudioModel': 'Belum ada model di studio.',
    'tab.craft': '③ Demonstrasi Keterampilan', 'tab.caption': '④ Label Multibahasa',
    'caption.translate': 'Terjemahkan ke ID / EN / MS / TH',
    'video.related': 'Video Terkait', 'video.none': 'Tidak ada video terkait', 'video.searchBtn': 'Cari Video Terkait',
    'studio.title': 'Studio Kreatif', 'studio.sub': 'Unggah foto lokal artefak atau kerajinan; Tripo AI membangun ulang model 3D. Satu gambar, empat tampakan, atau gambar ke tampakan.',
    'studio.modeling': 'Gambar ke 3D (Tripo)', 'studio.modeSingle': 'Satu Gambar', 'studio.modeMulti': 'Empat Tampakan', 'studio.modeMV': 'Gambar ke Tampakan',
    'studio.viewFront': 'Depan', 'studio.viewLeft': 'Kiri', 'studio.viewBack': 'Belakang', 'studio.viewRight': 'Kanan',
    'studio.multiHint': 'Tampak depan wajib; minimal 2 gambar. Objek sama, pencahayaan konsisten.',
    'studio.generate': 'Buat Model 3D', 'studio.genMV': 'Buat Tampakan',
    'studio.mvMock': 'Tampilan adalah placeholder (model gambar Ark belum aktif).',
    'studio.preview': 'Pratinjau 3D', 'studio.previewHint': 'Pratinjau model di sini saat selesai; rekaman terkait dapat dicari di bawah',
    'studio.exportModel': 'Unduh Model (.glb)', 'studio.saveImage': 'Simpan Gambar',
    'exhibit.segment': 'Segmentasi AI (Tripo)', 'exhibit.segmenting': 'Mensegmentasi…',
    'exhibit.segmentDone': 'Selesai — klik bagian di pratinjau untuk memilih atau menggabungkan', 'exhibit.segmentFailed': 'Segmentasi gagal, coba lagi',
    'exhibit.restore': 'Kembalikan Posisi Bagian', 'exhibit.partHint': 'Klik bagian untuk memilih; seret panah pada bagian untuk memindahkannya; klik dua bagian untuk menggabungkan; klik Kembalikan untuk mereset semua bagian.',
    'exhibit.partSelected': 'Dipilih: {name}', 'exhibit.partMerged': 'Digabung: {a} + {b}', 'exhibit.partEmpty': 'Belum ada bagian dipilih',
    'studio.upload3d': 'Unggah file 3D (.glb / .gltf)',
    'studio.vision': 'Analisis Gambar (Doubao Vision)', 'studio.visionBtn': 'Analisis Gambar',
    'community.showcase': 'Pameran Karya', 'community.review': 'Antrean Review (Pakar)',
    'community.forumSub': 'Masuk untuk berkirim di forum, melampirkan model dari studio, dan melihat unggahan pengguna lain.',
    'community.loginToPost': 'Masuk untuk berkirim dan melampirkan model.',
    'community.postPlaceholder': 'Bagikan ide, referensi atau pandangan Anda tentang karya ini…',
    'community.attachModel': 'Lampirkan model studio (opsional)', 'community.noModel': 'Tanpa model',
    'community.publish': 'Kirim', 'community.noPost': 'Belum ada kiriman, jadilah yang pertama.', 'community.emptyPost': 'Isi konten tidak boleh kosong',
    'community.expertOnly': 'Antrean review hanya untuk pakar yang disetujui. Daftar sebagai pakar dan tunggu persetujuan terlebih dahulu.',
    'review.approve': 'Setujui Tayang', 'review.reject': 'Kembalikan Revisi',
    'account.join': 'Bergabunglah', 'account.sub': 'Daftar akun independen untuk membuat model di studio, berkirim di forum dan melampirkan karya Anda.',
    'account.expert': 'Pakar', 'account.creator': 'Kreator',
    'account.profile': 'Akun Saya', 'account.logout': 'Keluar', 'account.login': 'Masuk', 'account.register': 'Daftar',
    'account.username': 'Nama pengguna', 'account.password': 'Kata sandi', 'account.name': 'Nama / Lembaga',
    'account.country': 'Negara / Wilayah', 'account.role': 'Peran', 'account.loginBtn': 'Masuk', 'account.registerBtn': 'Daftar',
    'account.loginSuccess': 'Berhasil masuk.', 'account.registerSuccess': 'Registrasi berhasil, masuk otomatis.',
    'account.countryPh': 'mis. Tiongkok · Malaysia · Indonesia · Australia',
    'brand.subtitle': 'Platform kolaborasi warisan budaya multibahasa Tiongkok–ASEAN', 'footer.text': 'Silu Heritage · Platform Warisan Budaya Digital — Prototipe v0.1',
    'index.title': 'Arsip Warisan Digital', 'index.sub': 'Model 3D · media HD · rekaman dokumenter · demo pembongkaran · demo keterampilan — setiap paket aset digital yang dapat dipakai ulang.',
    'index.empty': 'Tidak ada aset yang cocok. Coba sesuaikan filter atau kata kunci.',
    'filter.all': 'Semua', 'filter.any': 'Bebas',
    'cat.ceramic': 'Keramik', 'cat.textile': 'Tenun', 'cat.wood': 'Ukiran Kayu', 'cat.folk': 'Folklor',
    'country.cn': 'Tiongkok', 'country.id': 'Indonesia', 'country.my': 'Malaysia', 'country.au': 'Australia',
    'type.model': 'Model 3D', 'type.assembly': 'Demo Pembongkaran', 'type.craft': 'Demo Keterampilan', 'type.text': 'Artikel & Media', 'type.label': 'Label Multibahasa',
    'exhibit.notFound': 'Aset tidak ditemukan.',
    'overall.hintParts': 'Klik bagian mana pun untuk melihat keterangan', 'overall.clickExpand': 'Klik untuk membuka', 'overall.unit': 'Bentuk keseluruhan',
    'explode.noLayers': 'Belum ada data struktur berlapis untuk aset ini. Lapiskan di studio untuk membangun tampilan pembongkaran.',
    'explode.layerHint': 'Geser slider untuk membuka / merakit lapisan dan memahami urutan struktur dan keterampilan.', 'explode.layer': 'Lapisan {n}',
    'exhibit.segmentDesc': 'Tripo AI membagi model secara otomatis menjadi bagian yang dapat dibongkar.',
    'viewer.modelHint': 'Model 3D · putar / zoom · klik bagian', 'viewer.placeholderHint': 'Placeholder — model asli tampil setelah GLB Tripo dimuat',
    'viewer.placeholderCube': 'Pratinjau 3D', 'viewer.hintBase': 'Putar 360° · Zoom · Ukur (dimuat setelah GLB nyata terhubung)', 'viewer.partName': 'Bagian {n}',
    'studio.submitting': 'Mengirim tugas…', 'studio.queued': 'Tugas {id} dalam antrean…',
    'studio.modeling': 'Membangun… {status} {progress}', 'studio.modelDone': 'Modeling selesai.',
    'studio.modelMock': 'Selesai (placeholder: Tripo mengembalikan URL GLB setelah dibuat)', 'studio.modelFailed': 'Modeling gagal, coba lagi.',
    'studio.queryFailed': 'Kueri tugas gagal, muat ulang dan coba lagi: {msg}',
    'studio.selectPhoto': 'Pilih foto artefak atau kerajinan', 'studio.selectViewPhoto': 'Pilih foto untuk tampilan referensi',
    'studio.needFront': 'Tampak depan wajib diisi', 'studio.needTwo': 'Minimal 2 gambar tampakan valid',
    'studio.arkSubmitting': 'Mengirim ke model gambar Ark…', 'studio.viewDone': 'Tampilan referensi dibuat.',
    'studio.viewUnavailable': 'Tampilan tidak tersedia: {msg}', 'studio.viewPlaceholder': 'Placeholder — tampil setelah Ark mengembalikan URL tampilan',
    'studio.imageSaveFailed': 'Gagal menyimpan gambar: {msg}', 'studio.exportFailed': 'Ekspor gagal: {msg}', 'studio.submitFailed': 'Pengiriman gagal: {msg}',
    'studio.visionSelect': 'Pilih gambar terlebih dahulu.', 'studio.visionRunning': 'Menganalisis…', 'studio.visionFailed': 'Analisis gagal: {msg}',
    'studio.videoSelect': 'Pilih gambar terlebih dahulu sebelum mencari video terkait.', 'studio.videoFound': 'Rekaman terkait ditemukan.', 'studio.videoFailed': 'Pencarian video gagal: {msg}',
    'studio.local3d': 'File 3D lokal dipilih: {name} (prototipe hanya mencatat nama file)', 'studio.fourViewModel': 'Model empat tampakan',
    'error.request': 'Permintaan gagal HTTP {status}', 'error.download': 'Unduh gagal HTTP {status}',
    'error.usernameRequired': 'Masukkan nama pengguna', 'error.usernameTaken': 'Nama pengguna sudah dipakai', 'error.passwordShort': 'Kata sandi minimal 6 karakter', 'error.badCredentials': 'Nama pengguna atau kata sandi salah', 'error.unauthorized': 'Silakan masuk untuk berkirim',
  },
  ms: {
    'nav.library': 'Arkib Digital', 'nav.exhibit': 'Demonstrasi Objek & Kraf', 'nav.studio': 'Studio Kreatif',
    'nav.community': 'Komuniti Kolaborasi', 'nav.account': 'Daftar / Log Masuk',
    'search.placeholder': 'Cari warisan / kraf / pengrajin…', 'search.button': 'Cari',
    'filter.country': 'Negara / Wilayah Asal', 'filter.type': 'Jenis Aset', 'filter.status': 'Status Semakan',
    'result.count': '{n} aset',
    'status.approved': 'Dilulus Pakar', 'status.pending': 'Menunggu Semakan', 'status.machine': 'Hasil AI menunggu pengesahan',
    'tab.overall': '① Pandangan 3D Keseluruhan', 'tab.explode': '② Pembongkaran',
    'exhibit.studioModels': 'Model Studio', 'exhibit.studioSummary': 'Model yang dijana di studio.', 'exhibit.noStudioModel': 'Belum ada model di studio.',
    'tab.craft': '③ Demonstrasi Kraf', 'tab.caption': '④ Label Pelbagai Bahasa',
    'caption.translate': 'Terjemah ke EN / ID / MS / TH',
    'video.related': 'Video Berkaitan', 'video.none': 'Tiada video berkaitan', 'video.searchBtn': 'Cari Video Berkaitan',
    'studio.title': 'Studio Kreatif', 'studio.sub': 'Muat naik foto tempatan artifak atau kraf; Tripo AI bina semula model 3D. Satu gambar, empat pandangan, atau imej ke pandangan.',
    'studio.modeling': 'Imej ke 3D (Tripo)', 'studio.modeSingle': 'Satu Gambar', 'studio.modeMulti': 'Empat Pandangan', 'studio.modeMV': 'Imej ke Pandangan',
    'studio.viewFront': 'Depan', 'studio.viewLeft': 'Kiri', 'studio.viewBack': 'Belakang', 'studio.viewRight': 'Kanan',
    'studio.multiHint': 'Pandangan depan wajib; sekurang-kurangnya 2 gambar. Objek sama, cahaya konsisten.',
    'studio.generate': 'Jana Model 3D', 'studio.genMV': 'Jana Pandangan',
    'studio.mvMock': 'Pandangan adalah placeholder (model gambar Ark belum diaktifkan).',
    'studio.preview': 'Pratonton 3D', 'studio.previewHint': 'Pratonton model di sini apabila siap; rakaman berkaitan boleh dicari di bawah',
    'studio.exportModel': 'Eksport Model (.glb)', 'studio.saveImage': 'Simpan Imej',
    'exhibit.segment': 'Segmentasi AI (Tripo)', 'exhibit.segmenting': 'Menyegmen…',
    'exhibit.segmentDone': 'Siap — klik bahagian dalam pratonton untuk memilih atau menggabungkan', 'exhibit.segmentFailed': 'Segmentasi gagal, cuba lagi',
    'exhibit.restore': 'Pulihkan Kedudukan Bahagian', 'exhibit.partHint': 'Klik bahagian untuk memilih; seret anak panah pada bahagian untuk mengalihkannya; klik dua bahagian untuk menggabungkan; klik Pulihkan untuk menetapkan semula.',
    'exhibit.partSelected': 'Dipilih: {name}', 'exhibit.partMerged': 'Digabung: {a} + {b}', 'exhibit.partEmpty': 'Tiada bahagian dipilih',
    'studio.upload3d': 'Muat naik fail 3D (.glb / .gltf)',
    'studio.vision': 'Analisis Imej (Doubao Vision)', 'studio.visionBtn': 'Analisis Imej',
    'community.showcase': 'Pameran Karya', 'community.review': 'Giliran Semakan (Pakar)',
    'community.forumSub': 'Log masuk untuk menyiarkan di forum, melampirkan model daripada studio, dan melihat perkongsian pengguna lain.',
    'community.loginToPost': 'Log masuk untuk menyiarkan dan melampirkan model.',
    'community.postPlaceholder': 'Kongsi idea, rujukan atau pandangan anda tentang karya ini…',
    'community.attachModel': 'Lampirkan model studio (pilihan)', 'community.noModel': 'Tiada model',
    'community.publish': 'Siar', 'community.noPost': 'Belum ada siaran, jadilah yang pertama.', 'community.emptyPost': 'Kandungan tidak boleh kosong',
    'community.expertOnly': 'Giliran semakan hanya untuk pakar yang diluluskan. Daftar sebagai pakar dan dapatkan kelulusan dahulu.',
    'review.approve': 'Lulus Terbit', 'review.reject': 'Pulang Semakan',
    'account.join': 'Sertai Platform', 'account.sub': 'Daftar akaun independen untuk jana model di studio, siaran di forum dan lampirkan karya anda.',
    'account.expert': 'Pakar', 'account.creator': 'Pencipta',
    'account.profile': 'Akaun Saya', 'account.logout': 'Log Keluar', 'account.login': 'Log Masuk', 'account.register': 'Daftar',
    'account.username': 'Nama pengguna', 'account.password': 'Kata laluan', 'account.name': 'Nama / Organisasi',
    'account.country': 'Negara / Wilayah', 'account.role': 'Peranan', 'account.loginBtn': 'Log Masuk', 'account.registerBtn': 'Daftar',
    'account.loginSuccess': 'Log masuk berjaya.', 'account.registerSuccess': 'Pendaftaran berjaya, log masuk automatik.',
    'account.countryPh': 'cth. China · Malaysia · Indonesia · Australia',
    'brand.subtitle': 'Platform kolaborasi warisan budaya berbilang bahasa China–ASEAN', 'footer.text': 'Silu Heritage · Platform Warisan Budaya Digital — Prototaip v0.1',
    'index.title': 'Arkib Warisan Digital', 'index.sub': 'Model 3D · media HD · rakaman dokumentari · demo pembongkaran · demo kraf — setiap paket aset digital yang boleh diguna semula.',
    'index.empty': 'Tiada aset yang sepadan. Cuba laraskan penapis atau kata kunci.',
    'filter.all': 'Semua', 'filter.any': 'Apa-apa',
    'cat.ceramic': 'Seramik', 'cat.textile': 'Tenunan', 'cat.wood': 'Kerja Kayu', 'cat.folk': 'Rakyat',
    'country.cn': 'China', 'country.id': 'Indonesia', 'country.my': 'Malaysia', 'country.au': 'Australia',
    'type.model': 'Model 3D', 'type.assembly': 'Demo Pembongkaran', 'type.craft': 'Demo Kraf', 'type.text': 'Artikel & Media', 'type.label': 'Label Berbilang Bahasa',
    'exhibit.notFound': 'Aset tidak ditemui.',
    'overall.hintParts': 'Klik mana-mana bahagian untuk lihat penerangan', 'overall.clickExpand': 'Klik untuk kembangkan', 'overall.unit': 'Bentuk keseluruhan',
    'explode.noLayers': 'Tiada data struktur berlapis untuk aset ini. Lapiskan dalam studio untuk bina pandangan pembongkaran.',
    'explode.layerHint': 'Seret peluncur untuk kembangkan / pasang semula lapisan dan fahami susunan struktur dan kraf.', 'explode.layer': 'Lapisan {n}',
    'exhibit.segmentDesc': 'Tripo AI membahagikan model secara automatik kepada bahagian yang boleh dibongkar.',
    'viewer.modelHint': 'Model 3D · putar / zum · klik bahagian', 'viewer.placeholderHint': 'Placeholder — model sebenar muncul selepas GLB Tripo dimuat',
    'viewer.placeholderCube': 'Pratonton 3D', 'viewer.hintBase': 'Putar 360° · Zum · Ukur (dimuat selepas GLB sebenar disambung)', 'viewer.partName': 'Bahagian {n}',
    'studio.submitting': 'Menghantar tugas…', 'studio.queued': 'Tugas {id} dalam barisan…',
    'studio.modeling': 'Membina… {status} {progress}', 'studio.modelDone': 'Pemodelan selesai.',
    'studio.modelMock': 'Selesai (placeholder: Tripo memulangkan URL GLB selepas penjanaan)', 'studio.modelFailed': 'Pemodelan gagal, cuba lagi.',
    'studio.queryFailed': 'Pertanyaan tugas gagal, muat semula dan cuba lagi: {msg}',
    'studio.selectPhoto': 'Pilih foto artifak atau kraf', 'studio.selectViewPhoto': 'Pilih foto untuk pandangan rujukan',
    'studio.needFront': 'Pandangan depan diperlukan', 'studio.needTwo': 'Sekurang-kurangnya 2 gambar pandangan yang sah',
    'studio.arkSubmitting': 'Menghantar ke model imej Ark…', 'studio.viewDone': 'Pandangan rujukan dijana.',
    'studio.viewUnavailable': 'Pandangan tidak tersedia: {msg}', 'studio.viewPlaceholder': 'Placeholder — muncul selepas Ark memulangkan URL pandangan',
    'studio.imageSaveFailed': 'Simpan imej gagal: {msg}', 'studio.exportFailed': 'Eksport gagal: {msg}', 'studio.submitFailed': 'Penyerahan gagal: {msg}',
    'studio.visionSelect': 'Sila pilih imej dahulu.', 'studio.visionRunning': 'Menganalisis…', 'studio.visionFailed': 'Analisis gagal: {msg}',
    'studio.videoSelect': 'Pilih imej sebelum mencari video berkaitan.', 'studio.videoFound': 'Rakaman berkaitan ditemui.', 'studio.videoFailed': 'Carian video gagal: {msg}',
    'studio.local3d': 'Fail 3D tempatan dipilih: {name} (prototaip hanya merekod nama fail)', 'studio.fourViewModel': 'Model empat pandangan',
    'error.request': 'Permintaan gagal HTTP {status}', 'error.download': 'Muat turun gagal HTTP {status}',
    'error.usernameRequired': 'Sila masukkan nama pengguna', 'error.usernameTaken': 'Nama pengguna sudah digunakan', 'error.passwordShort': 'Kata laluan minimum 6 aksara', 'error.badCredentials': 'Nama pengguna atau kata laluan salah', 'error.unauthorized': 'Sila log masuk untuk menyiarkan',
  },
  th: {
    'nav.library': 'คลังดิจิทัล', 'nav.exhibit': 'การชิ้นส่วนและสาธิต', 'nav.studio': 'เวิร์กชอปสร้างสรรค์',
    'nav.community': 'ชุมชนร่วมสร้าง', 'nav.account': 'ลงทะเบียน/เข้าสู่ระบบ',
    'search.placeholder': 'ค้นหามรดก / ศิลปะ / ช่างฝีมือ…', 'search.button': 'ค้นหา',
    'filter.country': 'ประเทศ / ภูมิภาคต้นทาง', 'filter.type': 'ประเภทสินทรัพย์', 'filter.status': 'สถานะการตรวจสอบ',
    'result.count': '{n} สินทรัพย์',
    'status.approved': 'ผ่านการตรวจสอบโดยผู้เชี่ยวชาญ', 'status.pending': 'รอการตรวจสอบ', 'status.machine': 'สร้างโดย AI รอการตรวจสอบ',
    'tab.overall': '① มุมมอง 3D โดยรวม', 'tab.explode': '② แยกชิ้นส่วน',
    'exhibit.studioModels': 'โมเดลเวิร์กชอป', 'exhibit.studioSummary': 'โมเดลที่สร้างในเวิร์กชอป', 'exhibit.noStudioModel': 'ยังไม่มีโมเดลในเวิร์กชอป',
    'tab.craft': '③ สาธิตฝีมือ', 'tab.caption': '④ ป้ายหลายภาษา',
    'caption.translate': 'แปลเป็น อังกฤษ/อินโดนีเซีย/มาเลย์/ไทย',
    'video.related': 'วิดีโอที่เกี่ยวข้อง', 'video.none': 'ไม่มีวิดีโอที่เกี่ยวข้อง', 'video.searchBtn': 'ค้นหาวิดีโอที่เกี่ยวข้อง',
    'studio.title': 'เวิร์กชอปสร้างสรรค์', 'studio.sub': 'อัปโหลดภาพท้องถิ่น Tripo AI สร้างแบบจำลอง 3D รองรับภาพเดียว สี่มุมมอง หรือภาพเดียวสร้างมุมมอง',
    'studio.modeling': 'ภาพเป็น 3D (Tripo)', 'studio.modeSingle': 'ภาพเดียว', 'studio.modeMulti': 'สี่มุมมอง', 'studio.modeMV': 'ภาพเดียวเป็นมุมมอง',
    'studio.viewFront': 'ด้านหน้า', 'studio.viewLeft': 'ด้านซ้าย', 'studio.viewBack': 'ด้านหลัง', 'studio.viewRight': 'ด้านขวา',
    'studio.multiHint': 'ต้องมีมุมหน้า อย่างน้อย 2 ภาพ วัตถุเดียวกัน แสงสีสม่ำเสมอ',
    'studio.generate': 'สร้างโมเดล 3D', 'studio.genMV': 'สร้างมุมมอง',
    'studio.mvMock': 'มุมมองเป็นตัวอย่าง (โมเดลภาพ Ark ยังไม่เปิดใช้งาน)',
    'studio.preview': 'หน้าต่างพรีวิว 3D', 'studio.previewHint': 'พรีวิวโมเดลที่นี่เมื่อเสร็จ ค้นหาวิดีโอที่เกี่ยวข้องได้ด้านล่าง',
    'studio.exportModel': 'ส่งออกโมเดล (.glb)', 'studio.saveImage': 'บันทึกภาพ',
    'exhibit.segment': 'แบ่งชิ้นส่วน AI (Tripo)', 'exhibit.segmenting': 'กำลังแบ่งชิ้นส่วน…',
    'exhibit.segmentDone': 'แบ่งชิ้นส่วนเสร็จแล้ว คลิกชิ้นส่วนในพรีวิวเพื่อเลือกหรือรวมกลุ่ม', 'exhibit.segmentFailed': 'แบ่งชิ้นส่วนล้มเหลว ลองใหม่',
    'exhibit.restore': 'คืนชิ้นส่วน', 'exhibit.partHint': 'คลิกชิ้นส่วนเพื่อเลือก ลากลูกศรบนชิ้นส่วนเพื่อเลื่อน คลิกสองชิ้นส่วนเพื่อรวมกัน คลิกคืนชิ้นส่วนเพื่อรีเซ็ตทั้งหมด',
    'exhibit.partSelected': 'เลือกแล้ว: {name}', 'exhibit.partMerged': 'รวมแล้ว: {a} + {b}', 'exhibit.partEmpty': 'ยังไม่ได้เลือกชิ้นส่วน',
    'studio.upload3d': 'อัปโหลดไฟล์ 3D ที่มีอยู่ (.glb / .gltf)',
    'studio.vision': 'วิเคราะห์ภาพ (Doubao Vision)', 'studio.visionBtn': 'วิเคราะห์ภาพ',
    'community.showcase': 'ผลงานแสดง', 'community.review': 'คิวตรวจสอบ (ผู้เชี่ยวชาญ)',
    'community.forumSub': 'เข้าสู่ระบบเพื่อตั้งกระทู้ในฟอรัม แนบโมเดลจากเวิร์กชอป และดูการแชร์ของผู้ใช้อื่น',
    'community.loginToPost': 'เข้าสู่ระบบเพื่อตั้งกระทู้และแนบโมเดล',
    'community.postPlaceholder': 'แบ่งปันแนวทาง แหล่งอ้างอิง หรือความคิดเห็นเกี่ยวกับผลงาน…',
    'community.attachModel': 'แนบโมเดลเวิร์กชอป (ไม่บังคับ)', 'community.noModel': 'ไม่แนบโมเดล',
    'community.publish': 'เผยแพร่', 'community.noPost': 'ยังไม่มีกระทู้ มาตั้งกระทู้แรกกัน', 'community.emptyPost': 'เนื้อหาห้ามว่าง',
    'community.expertOnly': 'คิวตรวจสอบเปิดเฉพาะผู้เชี่ยวชาญที่ผ่านการอนุมัติเท่านั้น โปรดสมัครเป็นผู้เชี่ยวชาญและรอการอนุมัติก่อน',
    'review.approve': 'อนุมัติเผยแพร่', 'review.reject': 'ส่งกลับแก้ไข',
    'account.join': 'เข้าร่วมแพลตฟอร์ม', 'account.sub': 'สมัครบัญชีแยกกันเพื่อสร้างโมเดลในเวิร์กชอป ตั้งกระทู้ในฟอรัม และแนบผลงานของคุณ',
    'account.expert': 'ผู้เชี่ยวชาญ', 'account.creator': 'ผู้สร้าง',
    'account.profile': 'บัญชีของฉัน', 'account.logout': 'ออกจากระบบ', 'account.login': 'เข้าสู่ระบบ', 'account.register': 'สมัคร',
    'account.username': 'ชื่อผู้ใช้', 'account.password': 'รหัสผ่าน', 'account.name': 'ชื่อ / หน่วยงาน',
    'account.country': 'ประเทศ / ภูมิภาค', 'account.role': 'บทบาท', 'account.loginBtn': 'เข้าสู่ระบบ', 'account.registerBtn': 'สมัคร',
    'account.loginSuccess': 'เข้าสู่ระบบสำเร็จ', 'account.registerSuccess': 'สมัครสำเร็จ เข้าสู่ระบบอัตโนมัติ',
    'account.countryPh': 'เช่น จีน · มาเลเซีย · อินโดนีเซีย · ออสเตรเลีย',
    'brand.subtitle': 'แพลตฟอร์มร่วมสร้างมรดกทางวัฒนธรรมหลายภาษา จีน–อาเซียน', 'footer.text': 'Silu Heritage · แพลตฟอร์มมรดกทางวัฒนธรรมดิจิทัล — ต้นแบบ v0.1',
    'index.title': 'คลังมรดกดิจิทัล', 'index.sub': 'โมเดล 3D · สื่อ HD · ภาพยนตร์สารคดี · สาธิตการแยกชิ้นส่วน · สาธิตฝีมือ — แต่ละชุดเป็นแพ็กเกจสินทรัพย์ดิจิทัลที่นำกลับมาใช้ได้',
    'index.empty': 'ไม่พบสินทรัพย์ที่ตรงกัน ลองปรับตัวกรองหรือคำค้น',
    'filter.all': 'ทั้งหมด', 'filter.any': 'ไม่จำกัด',
    'cat.ceramic': 'เครื่องปั้นดินเผา', 'cat.textile': 'ทอผ้า', 'cat.wood': 'งานไม้', 'cat.folk': 'พื้นบ้าน',
    'country.cn': 'จีน', 'country.id': 'อินโดนีเซีย', 'country.my': 'มาเลเซีย', 'country.au': 'ออสเตรเลีย',
    'type.model': 'โมเดล 3D', 'type.assembly': 'สาธิตการแยกชิ้นส่วน', 'type.craft': 'สาธิตฝีมือมรดก', 'type.text': 'บทความ & สื่อ', 'type.label': 'ป้ายหลายภาษา',
    'exhibit.notFound': 'ไม่พบสินทรัพย์ที่เกี่ยวข้อง',
    'overall.hintParts': 'คลิกชิ้นส่วนใดเพื่อดูคำอธิบาย', 'overall.clickExpand': 'คลิกเพื่อขยาย', 'overall.unit': 'รูปร่างโดยรวม',
    'explode.noLayers': 'สินทรัพย์นี้ยังไม่มีข้อมูลโครงสร้างชั้น สร้างชั้นในเวิร์กชอปเพื่อทำมุมมองแยกชิ้นส่วน',
    'explode.layerHint': 'ลากแถบเลื่อนเพื่อแยก / ประกอบชั้นต่าง ๆ และทำความเข้าใจโครงสร้างและลำดับฝีมือ', 'explode.layer': 'ชั้น {n}',
    'exhibit.segmentDesc': 'Tripo AI แบ่งโมเดลออกเป็นชิ้นส่วนที่แยกประกอบได้อัตโนมัติ',
    'viewer.modelHint': 'โมเดล 3D · หมุน / ซูม · คลิกชิ้นส่วน', 'viewer.placeholderHint': 'รูปร่างตัวอย่าง · โมเดลจริงจะแสดงหลังโหลด GLB จาก Tripo',
    'viewer.placeholderCube': 'พื้นที่พรีวิว 3D', 'viewer.hintBase': 'หมุน 360° · ซูม · วัด (โหลดหลังเชื่อมต่อ GLB จริง)', 'viewer.partName': 'ชิ้นส่วน {n}',
    'studio.submitting': 'กำลังส่งงาน…', 'studio.queued': 'งาน {id} อยู่ในคิว…',
    'studio.modeling': 'กำลังสร้าง… {status} {progress}', 'studio.modelDone': 'สร้างโมเดลเสร็จ',
    'studio.modelMock': 'เสร็จแล้ว (ตัวอย่าง — Tripo จะคืน URL GLB หลังสร้าง)', 'studio.modelFailed': 'สร้างโมเดลล้มเหลว โปรดลองใหม่',
    'studio.queryFailed': 'สอบถามงานล้มเหลว โปรดรีเฟรชแล้วลองอีกครั้ง: {msg}',
    'studio.selectPhoto': 'โปรดเลือกภาพโบราณวัตถุหรืองานฝีมือ', 'studio.selectViewPhoto': 'โปรดเลือกภาพสำหรับสร้างมุมมองอ้างอิง',
    'studio.needFront': 'ต้องมีมุมมองด้านหน้า', 'studio.needTwo': 'ต้องมีภาพมุมมองที่ถูกต้องอย่างน้อย 2 ภาพ',
    'studio.arkSubmitting': 'กำลังส่งไปยังโมเดลภาพ Ark…', 'studio.viewDone': 'สร้างมุมมองอ้างอิงแล้ว',
    'studio.viewUnavailable': 'มุมมองไม่พร้อมใช้งาน: {msg}', 'studio.viewPlaceholder': 'ตัวอย่าง — จะแสดงหลัง Ark คืน URL มุมมอง',
    'studio.imageSaveFailed': 'บันทึกภาพล้มเหลว: {msg}', 'studio.exportFailed': 'ส่งออกล้มเหลว: {msg}', 'studio.submitFailed': 'ส่งข้อมูลล้มเหลว: {msg}',
    'studio.visionSelect': 'โปรดเลือกภาพก่อน', 'studio.visionRunning': 'กำลังวิเคราะห์…', 'studio.visionFailed': 'วิเคราะห์ล้มเหลว: {msg}',
    'studio.videoSelect': 'เลือกภาพก่อนค้นหาวิดีโอที่เกี่ยวข้อง', 'studio.videoFound': 'พบภาพที่เกี่ยวข้องแล้ว', 'studio.videoFailed': 'ค้นหาวิดีโอล้มเหลว: {msg}',
    'studio.local3d': 'เลือกไฟล์ 3D ในเครื่องแล้ว: {name} (ต้นแบบบันทึกเฉพาะชื่อไฟล์)', 'studio.fourViewModel': 'โมเดลสี่มุมมอง',
    'error.request': 'คำขอล้มเหลว HTTP {status}', 'error.download': 'ดาวน์โหลดล้มเหลว HTTP {status}',
    'error.usernameRequired': 'กรุณากรอกชื่อผู้ใช้', 'error.usernameTaken': 'ชื่อผู้ใช้ถูกใช้แล้ว', 'error.passwordShort': 'รหัสผ่านอย่างน้อย 6 ตัวอักษร', 'error.badCredentials': 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง', 'error.unauthorized': 'โปรดเข้าสู่ระบบก่อนตั้งกระทู้',
  },
};

function currentLang() {
  return localStorage.getItem('silu-lang') || 'zh';
}
function setLang(lang) {
  if (!SUPPORTED_LANGS.includes(lang)) lang = 'zh';
  localStorage.setItem('silu-lang', lang);
  document.dispatchEvent(new CustomEvent('langchange', { detail: { lang } }));
  renderLangSwitch();
  applyI18n();
}

function t(key, vars) {
  const lang = currentLang();
  let s = (I18N[lang] && I18N[lang][key]) || I18N.zh[key] || key;
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.replace(`{${k}}`, v);
  return s;
}

/** 审核状态文案本地化 */
/** 后端常见中文错误提示映射到当前语言；未收录的原样返回 */
const ERROR_MAP = {
  '请输入用户名': 'error.usernameRequired',
  '用户名已被占用': 'error.usernameTaken',
  '密码至少 6 位': 'error.passwordShort',
  '用户名或密码错误': 'error.badCredentials',
  '未登录': 'error.unauthorized',
  '请先登录后发言': 'error.unauthorized',
};
function tError(message) {
  const key = ERROR_MAP[message];
  return key ? t(key) : message;
}

function tStatus(status) {
  if (status === '已通过专家审核') return t('status.approved');
  if (status === '待审核') return t('status.pending');
  return t('status.machine');
}

function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
  const titleEl = document.querySelector('title[data-i18n-title]');
  if (titleEl) document.title = t(titleEl.dataset.i18nTitle);
}

function renderLangSwitch() {
  const box = document.querySelector('.lang-switch');
  if (!box) return;
  const lang = currentLang();
  box.innerHTML = SUPPORTED_LANGS.map(
    (l) => `<button data-lang="${l}" class="${l === lang ? 'active' : ''}">${LANG_LABEL[l]}</button>`,
  ).join('');
  box.querySelectorAll('button').forEach((b) =>
    b.addEventListener('click', () => setLang(b.dataset.lang)),
  );
}

/** 根据资产 cover 配置生成渐变色块 */
function coverStyle(cover) {
  const hue = (cover?.hue ?? 20) + (cover?.seed ?? 0) * 4;
  return `background: linear-gradient(135deg, hsl(${hue} 42% 52%), hsl(${hue + 30} 38% 34%))`;
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** 拉取远程地址为 Blob（经后端代理时同源，避免跨域拦截） */
async function fetchBlob(url) {
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(t('error.download', { status: resp.status }));
  return resp.blob();
}

/**
 * 保存 Blob：优先调用系统文件选择器让用户自选保存位置；
 * 浏览器不支持 File System Access API 时回退到默认下载目录。
 */
async function saveBlob(blob, suggestedName, mimeAccept = '') {
  if (window.showSaveFilePicker) {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName,
        ...(mimeAccept ? { types: [{ description: suggestedName, accept: { [blob.type || 'application/octet-stream']: [mimeAccept] } }] } : {}),
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return 'picker';
    } catch (e) {
      if (e && e.name === 'AbortError') return 'cancelled'; // 用户取消选择
      // 其他异常走回退方案
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = suggestedName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return 'download';
}

function highlightNav() {
  const page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.topnav a').forEach((a) => {
    const href = a.getAttribute('href');
    a.classList.toggle('active', href === page);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  highlightNav();
  renderLangSwitch();
  applyI18n();
});
