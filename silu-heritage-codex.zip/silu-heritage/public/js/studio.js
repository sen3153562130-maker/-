/* ===== 创作工坊：Tripo 单图 / 四视图 / 单图生三视图 · 豆包视觉识别 · 相关视频检索 ===== */

let tripoTimer = null;
let mode = 'single';
let currentModelId = null;
let currentModelUrl = null;

const singleFile = { file: null };
const viewFiles = { front: null, left: null, back: null, right: null };
const mvFile = { file: null };
const visionFile = { file: null };

/* ---------- 文件读取 ---------- */
function readFileB64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      const comma = result.indexOf(',');
      resolve({ name: file.name, mime: file.type || 'application/octet-stream', dataB64: comma >= 0 ? result.slice(comma + 1) : result });
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function readFileDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

async function uploadImage(file) {
  const payload = await readFileB64(file);
  const data = await api('/api/tripo/upload', { method: 'POST', body: JSON.stringify(payload) });
  return data.file_token;
}

function bindPreview(input, previewEl, store) {
  input.addEventListener('change', () => {
    const file = input.files?.[0] || null;
    store.file = file;
    if (file) {
      previewEl.src = URL.createObjectURL(file);
      previewEl.hidden = false;
    } else {
      previewEl.hidden = true;
      previewEl.removeAttribute('src');
    }
  });
}

/* ---------- 状态提示 ---------- */
function setTripoStatus(text, mock) {
  const el = document.getElementById('tripo-status');
  el.hidden = false;
  el.textContent = text;
  el.className = 'mock-tip' + (mock ? '' : ' ok');
}

/* ---------- 建模提交 ---------- */
async function saveModel(meta) {
  try {
    const r = await api('/api/models', { method: 'POST', body: JSON.stringify(meta) });
    return r.item || null;
  } catch { return null; /* 演示阶段：保存失败不阻断出模 */ }
}

/** 仅在传入新模型地址时替换预览窗口中的旧模型；未传入则保留现状 */
function mountStudioViewer(modelUrl) {
  const el = document.getElementById('studio-viewer');
  if (!el) return;
  const doMount = () => window.SiluViewer && window.SiluViewer.mount(el, modelUrl || null);
  if (window.SiluViewer) doMount();
  else document.addEventListener('silu-viewer-ready', doMount, { once: true });
}

function setExportAvailable(record) {
  const btn = document.getElementById('btn-export-model');
  if (!btn) return;
  if (record && record.id && record.modelUrl) {
    currentModelId = record.id;
    currentModelUrl = record.modelUrl;
    btn.hidden = false;
    btn.onclick = async () => {
      try {
        const blob = await fetchBlob(`/api/models/${record.id}/download`);
        const base = String(record.title || 'model').replace(/\.[a-z0-9]+$/i, '');
        await saveBlob(blob, `${base}.glb`, '.glb');
      } catch (e) {
        setTripoStatus(t('studio.exportFailed', { msg: e.message }), true);
      }
    };
  } else {
    btn.hidden = true;
    btn.onclick = null;
  }
}

async function generateSingle() {
  if (!singleFile.file) throw new Error(t('studio.selectPhoto'));
  setTripoStatus(t('studio.submitting'));
  const input = await uploadImage(singleFile.file);
  const created = await api('/api/tripo/image-to-model', { method: 'POST', body: JSON.stringify({ input }) });
  setTripoStatus(t('studio.queued', { id: created.task_id }), created.mock);
  pollTripo(created.task_id, created.mock, 'model', { title: singleFile.file.name, source: 'single-image' });
}

async function collectViewInputs() {
  const views = ['front', 'left', 'back', 'right'];
  const inputs = [];
  for (const v of views) {
    if (viewFiles[v] && viewFiles[v].file) {
      const token = await uploadImage(viewFiles[v].file);
      inputs.push({ [v]: token });
    }
  }
  if (!inputs.some((o) => o.front)) throw new Error(t('studio.needFront'));
  if (inputs.length < 2) throw new Error(t('studio.needTwo'));
  return inputs;
}

async function generateMulti() {
  setTripoStatus(t('studio.submitting'));
  const inputs = await collectViewInputs();
  const created = await api('/api/tripo/multiview-to-model', { method: 'POST', body: JSON.stringify({ inputs }) });
  setTripoStatus(t('studio.queued', { id: created.task_id }), created.mock);
  const title = viewFiles.front && viewFiles.front.file ? viewFiles.front.file.name : t('studio.fourViewModel');
  pollTripo(created.task_id, created.mock, 'model', { title, source: 'four-views' });
}

let mvImageUrl = null;

async function generateMultiview() {
  if (!mvFile.file) throw new Error(t('studio.selectViewPhoto'));
  setTripoStatus(t('studio.arkSubmitting'));
  const imageUrl = await readFileDataURL(mvFile.file);
  try {
    const r = await api('/api/ark/multiview', { method: 'POST', body: JSON.stringify({ imageUrl }) });
    mvImageUrl = r.image || null;
    renderMVView(mvImageUrl);
    setTripoStatus(r.mock ? t('studio.mvMock') : t('studio.viewDone'), r.mock);
  } catch (e) {
    mvImageUrl = null;
    renderMVView(null);
    setTripoStatus(t('studio.viewUnavailable', { msg: e.message }), true);
  }
}

function renderMVView(url) {
  const box = document.getElementById('mv-views');
  const saveBtn = document.getElementById('btn-save-mv');
  if (url) {
    box.innerHTML = `
      <div class="view-slot">
        <label>${t('studio.viewFront')}</label>
        <img class="thumb" src="${url}" alt="${t('studio.viewFront')}" />
      </div>`;
    saveBtn.hidden = false;
  } else {
    box.innerHTML = `<div class="view-slot"><div class="mock-tip" style="margin:0">${t('studio.viewPlaceholder')}</div></div>`;
    saveBtn.hidden = true;
  }
}

async function saveMVImage() {
  if (!mvImageUrl) return;
  try {
    const proxy = `/api/ark/proxy?url=${encodeURIComponent(mvImageUrl)}`;
    const blob = await fetchBlob(proxy);
    const type = blob.type || '';
    const ext = type.includes('webp') ? '.webp' : type.includes('jpeg') || type.includes('jpg') ? '.jpg' : '.png';
    await saveBlob(blob, `artifact-view${ext}`, ext);
  } catch (e) {
    setTripoStatus(t('studio.imageSaveFailed', { msg: e.message }), true);
  }
}

let pollFails = 0;

function persistPending(id, mock, meta) {
  try { sessionStorage.setItem('tripo-pending', JSON.stringify({ id, mock, meta })); } catch { /* 忽略存储异常 */ }
}

function clearPending() {
  try { sessionStorage.removeItem('tripo-pending'); } catch { /* 忽略 */ }
}

function pollTripo(id, mock, kind, meta = {}) {
  if (tripoTimer) clearInterval(tripoTimer);
  pollFails = 0;
  persistPending(id, mock, meta);
  setTripoStatus(t('studio.queued', { id }), mock);
  tripoTimer = setInterval(async () => {
    let task;
    try {
      task = await api(`/api/tripo/tasks/${id}`);
      pollFails = 0;
    } catch (e) {
      // 单次轮询失败（网络抖动 / 后端短暂重启）不终止轮询，连续失败 8 次才放弃
      pollFails += 1;
      if (pollFails >= 8) {
        clearInterval(tripoTimer);
        setTripoStatus(t('studio.queryFailed', { msg: e.message }), mock);
      }
      return;
    }
    setTripoStatus(t('studio.modeling', { status: task.status, progress: task.progress ?? '' }), mock);
    if (task.status === 'success') {
      clearInterval(tripoTimer);
      clearPending();
      const out = task.output || {};
      const modelUrl = out.model_url || (out.model && out.model.url) || null;
      if (modelUrl) {
        setTripoStatus(t('studio.modelDone'), mock);
        const record = await saveModel({ title: meta.title, source: meta.source, modelUrl, views: null });
        // 新模型就绪后才替换预览窗口中的原模型
        mountStudioViewer(modelUrl);
        setExportAvailable(record || { id: null, modelUrl });
      } else {
        setTripoStatus(t('studio.modelMock'), mock);
        await saveModel({ title: meta.title, source: meta.source, modelUrl: null, views: null });
      }
    } else if (['failed', 'cancelled', 'expired'].includes(task.status)) {
      clearInterval(tripoTimer);
      clearPending();
      setTripoStatus(t('studio.modelFailed'), mock);
    }
  }, 2000);
}

function resumePending() {
  let pending = null;
  try { pending = JSON.parse(sessionStorage.getItem('tripo-pending') || 'null'); } catch { pending = null; }
  if (pending && pending.id) pollTripo(pending.id, !!pending.mock, 'model', pending.meta || {});
}

/* ---------- 视觉识别 ---------- */
async function analyzeVision() {
  const result = document.getElementById('vision-result');
  if (!visionFile.file) { result.textContent = t('studio.visionSelect'); return; }
  result.textContent = t('studio.visionRunning');
  try {
    const imageUrl = await readFileDataURL(visionFile.file);
    const r = await api('/api/ark/vision', { method: 'POST', body: JSON.stringify({ imageUrl }) });
    result.textContent = r.analysis;
  } catch (e) {
    result.textContent = t('studio.visionFailed', { msg: e.message });
  }
}

/* ---------- 相关视频检索 ---------- */
function activeImageFile() {
  if (mode === 'single') return singleFile.file;
  if (mode === 'mv') return mvFile.file;
  return (viewFiles.front && viewFiles.front.file) || null;
}

async function searchRelatedVideo() {
  const box = document.getElementById('studio-video');
  const player = document.getElementById('studio-video-player');
  const file = activeImageFile();
  if (!file) { setTripoStatus(t('studio.videoSelect')); return; }
  try {
    const imageUrl = await readFileDataURL(file);
    const data = await api(`/api/video/search?imageUrl=${encodeURIComponent(imageUrl)}`);
    if (data.found && data.videoUrl) {
      box.style.display = 'block';
      player.src = data.videoUrl;
      setTripoStatus(t('studio.videoFound'));
    } else {
      box.style.display = 'none';
      setTripoStatus(t('video.none'));
    }
  } catch (e) {
    box.style.display = 'none';
    setTripoStatus(t('studio.videoFailed', { msg: e.message }));
  }
}

/* ---------- 模式切换 ---------- */
function switchMode(next) {
  mode = next;
  document.getElementById('mode-single').hidden = mode !== 'single';
  document.getElementById('mode-multi').hidden = mode !== 'multi';
  document.getElementById('mode-mv').hidden = mode !== 'mv';
  document.getElementById('tab-single').classList.toggle('active', mode === 'single');
  document.getElementById('tab-multi').classList.toggle('active', mode === 'multi');
  document.getElementById('tab-mv').classList.toggle('active', mode === 'mv');
}

function bindStaticButtons() {
  bindPreview(document.getElementById('single-file'), document.getElementById('single-preview'), singleFile);
  ['front', 'left', 'back', 'right'].forEach((v) => {
    viewFiles[v] = { file: null };
    bindPreview(document.querySelector(`[data-view="${v}"]`), document.querySelector(`[data-view-preview="${v}"]`), viewFiles[v]);
  });
  bindPreview(document.getElementById('mv-file'), document.getElementById('mv-preview'), mvFile);
  bindPreview(document.getElementById('vision-file'), document.getElementById('vision-preview'), visionFile);

  document.getElementById('tab-single').addEventListener('click', () => switchMode('single'));
  document.getElementById('tab-multi').addEventListener('click', () => switchMode('multi'));
  document.getElementById('tab-mv').addEventListener('click', () => switchMode('mv'));

  document.getElementById('btn-single-gen').addEventListener('click', () => generateSingle().catch((e) => setTripoStatus(t('studio.submitFailed', { msg: e.message }), true)));
  document.getElementById('btn-multi-gen').addEventListener('click', () => generateMulti().catch((e) => setTripoStatus(t('studio.submitFailed', { msg: e.message }), true)));
  document.getElementById('btn-mv-gen').addEventListener('click', () => generateMultiview().catch((e) => setTripoStatus(t('studio.submitFailed', { msg: e.message }), true)));
  document.getElementById('btn-vision').addEventListener('click', analyzeVision);
  document.getElementById('btn-search-video').addEventListener('click', searchRelatedVideo);
  document.getElementById('btn-save-mv').addEventListener('click', saveMVImage);

  document.getElementById('model-file').addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setTripoStatus(t('studio.local3d', { name: file.name }));
    saveModel({ title: file.name, source: 'upload-3d', modelUrl: null, views: null });
  });
}

async function restoreLatestModel() {
  try {
    const data = await api('/api/models');
    const rec = (data.items || []).find((x) => x.modelUrl);
    if (rec) {
      mountStudioViewer(rec.modelUrl);
      setExportAvailable(rec);
    }
  } catch { /* 本地无历史模型时保留占位 */ }
}

document.addEventListener('DOMContentLoaded', () => {
  bindStaticButtons();
  mountStudioViewer(null);
  restoreLatestModel();
  resumePending();
});
