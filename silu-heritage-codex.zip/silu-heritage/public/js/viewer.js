/* ===== 3D 预览：Three.js + OrbitControls + GLTFLoader（本地 vendor，无 CDN 依赖） ===== */
import * as THREE from 'three';
import { OrbitControls } from '/vendor/jsm/controls/OrbitControls.js';
import { TransformControls } from '/vendor/jsm/controls/TransformControls.js';
import { GLTFLoader } from '/vendor/jsm/loaders/GLTFLoader.js';

const instances = new WeakMap();

function dispose(el) {
  const inst = instances.get(el);
  if (!inst) return;
  if (inst.tc) { inst.tc.detach(); inst.tc.dispose(); }
  inst.controls.dispose();
  inst.renderer.dispose();
  inst.scene.clear();
  el.innerHTML = '';
  instances.delete(el);
}

function fitObject(obj) {
  const box = new THREE.Box3().setFromObject(obj);
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const max = Math.max(size.x, size.y, size.z) || 1;
  obj.scale.multiplyScalar(1.6 / max);
  obj.position.sub(center);
}

function makePlaceholder() {
  // 演示用占位器型：花瓶旋转体
  const points = [
    [0.0, 0.0], [0.32, 0.05], [0.42, 0.25], [0.38, 0.55], [0.22, 0.8], [0.16, 0.95], [0.2, 1.05],
  ].map(([x, y]) => new THREE.Vector2(x, y));
  const geo = new THREE.LatheGeometry(points, 40);
  geo.center();
  const mat = new THREE.MeshStandardMaterial({
    color: 0xc89b5a, roughness: 0.6, metalness: 0.15, side: THREE.DoubleSide,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.scale.setScalar(1.15);
  return mesh;
}

function materialList(mesh) {
  return Array.isArray(mesh.material) ? mesh.material : [mesh.material];
}

function cloneMaterial(mat) {
  if (!mat) return mat;
  return Array.isArray(mat) ? mat.map((m) => m.clone()) : mat.clone();
}

/** 收集模型部件：记录原始变换，克隆材质以支持独立高亮 */
function collectParts(root) {
  const parts = [];
  if (!root) return parts;
  const box = new THREE.Box3().setFromObject(root);
  const center = box.getCenter(new THREE.Vector3());
  const size = box.getSize(new THREE.Vector3()).length();
  root.traverse((obj) => {
    if (!obj.isMesh) return;
    const meshBox = new THREE.Box3().setFromObject(obj);
    if (meshBox.isEmpty()) return;
    obj.material = cloneMaterial(obj.material);
    const materials = materialList(obj);
    const meshCenter = meshBox.getCenter(new THREE.Vector3());
    const dir = meshCenter.clone().sub(center);
    if (dir.lengthSq() < 1e-6) dir.set(0, 1, 0);
    dir.normalize();
    const radius = meshBox.getSize(new THREE.Vector3()).length() / 2;
    parts.push({
      mesh: obj,
      name: obj.name || t('viewer.partName', { n: parts.length + 1 }),
      origPos: obj.position.clone(),
      origQuat: obj.quaternion.clone(),
      origScale: obj.scale.clone(),
      materials,
      emissiveOrig: materials.map((m) => (m.emissive ? m.emissive.clone() : null)),
      dir,
      dist: Math.max(size * 0.28, radius * 1.2),
    });
  });
  return parts;
}

function setPartHighlight(part, on) {
  part.materials.forEach((m, i) => {
    if (!m || !m.emissive) return;
    if (on) m.emissive.set(0xc89b5a);
    else if (part.emissiveOrig[i]) m.emissive.copy(part.emissiveOrig[i]);
  });
}

function groupOf(inst, part) {
  return inst.groups.find((g) => g.includes(part)) || null;
}

function highlightGroup(inst, group, on) {
  group.forEach((p) => setPartHighlight(p, on));
}

function clearSelection(inst) {
  if (!inst) return;
  if (inst.selected) {
    const g = groupOf(inst, inst.selected);
    highlightGroup(inst, g || [inst.selected], false);
  }
  if (inst.tc) { inst.tc.detach(); inst.tc.getHelper().visible = false; }
  inst.selected = null;
}

function attachGizmo(inst, mesh) {
  if (inst.tc && mesh) { inst.tc.attach(mesh); inst.tc.getHelper().visible = true; }
}

/** 拆装：点击部件 → 选中；再次点击另一部件 → 合并为一组；点击空白处取消 */
function handlePartClick(inst, part) {
  if (!inst) return;
  const group = groupOf(inst, part);
  if (inst.selected) {
    const selGroup = groupOf(inst, inst.selected);
    if (selGroup && selGroup.includes(part)) {
      clearSelection(inst);
      inst.onInteraction?.({ type: 'clear' });
      return;
    }
    const merged = [...new Set([...(selGroup || [inst.selected]), ...(group || [part])])];
    inst.groups = inst.groups.filter((g) => g !== selGroup && g !== group);
    inst.groups.push(merged);
    clearSelection(inst);
    inst.selected = merged[0];
    highlightGroup(inst, merged, true);
    attachGizmo(inst, merged[0].mesh);
    inst.onInteraction?.({ type: 'merged', parts: merged.map((p) => p.name) });
  } else {
    clearSelection(inst);
    inst.selected = part;
    highlightGroup(inst, group || [part], true);
    attachGizmo(inst, part.mesh);
    inst.onInteraction?.({ type: 'select', name: part.name });
  }
}

/** 还原全部部件到原始装配位置，清空选中与合并分组 */
function restoreAll(inst) {
  if (!inst) return;
  if (inst.tc) { inst.tc.detach(); inst.tc.getHelper().visible = false; }
  inst.groups = [];
  inst.selected = null;
  for (const p of inst.parts) {
    p.mesh.position.copy(p.origPos);
    p.mesh.quaternion.copy(p.origQuat);
    p.mesh.scale.copy(p.origScale);
    setPartHighlight(p, false);
  }
  inst.onInteraction?.({ type: 'restore' });
}

/** 开关部件点选 / 拖拽交互（仅拆装页拆解后的模型启用） */
function setInteractive(inst, on) {
  if (inst) inst.interactive = !!on;
}

/** 分层资产的逐层展开：factor 0 = 合拢，1 = 完全展开 */
function setExplode(inst, factor) {
  if (!inst || !inst.parts) return;
  const f = Math.min(1, Math.max(0, factor));
  for (const p of inst.parts) {
    p.mesh.position.copy(p.origPos).addScaledVector(p.dir, f * p.dist);
  }
}

function mount(el, modelUrl) {
  if (!el) return;
  dispose(el);
  el.innerHTML = '';
  const rect = el.getBoundingClientRect();
  const w = rect.width || 600;
  const h = rect.height || 360;

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setSize(w, h);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  el.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x1f1a16);
  const camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 100);
  camera.position.set(0, 0.6, 3.2);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.target.set(0, 0, 0);

  scene.add(new THREE.AmbientLight(0xffffff, 0.75));
  const dir = new THREE.DirectionalLight(0xfff0dd, 1.4);
  dir.position.set(3, 5, 4);
  scene.add(dir);
  const dir2 = new THREE.DirectionalLight(0x8899ff, 0.4);
  dir2.position.set(-3, 2, -4);
  scene.add(dir2);

  let current = null;
  let parts = [];

  const tc = new TransformControls(camera, renderer.domElement);
  tc.setMode('translate');
  tc.setSize(1.1);
  tc.getHelper().visible = false;
  scene.add(tc.getHelper());
  tc.addEventListener('dragging-changed', (e) => { controls.enabled = !e.value; });

  const inst = {
    renderer, scene, camera, controls, current, parts, tc,
    groups: [], selected: null, onInteraction: null, interactive: false,
  };

  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  let downX = 0;
  let downY = 0;

  const onPointerDown = (e) => { downX = e.clientX; downY = e.clientY; };
  const onPointerUp = (e) => {
    if (tc.dragging) return; // 正在拖动手柄，不触发点选
    if (!inst.interactive) return;
    if (Math.hypot(e.clientX - downX, e.clientY - downY) > 5) return; // 拖拽旋转，不触发点选
    if (!parts.length) return;
    const rect2 = renderer.domElement.getBoundingClientRect();
    pointer.x = ((e.clientX - rect2.left) / rect2.width) * 2 - 1;
    pointer.y = -((e.clientY - rect2.top) / rect2.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const hits = raycaster.intersectObjects(parts.map((p) => p.mesh), false);
    if (!hits.length) {
      clearSelection(inst);
      inst.onInteraction?.({ type: 'clear' });
      return;
    }
    const part = parts.find((p) => p.mesh === hits[0].object);
    if (part) handlePartClick(inst, part);
  };
  renderer.domElement.addEventListener('pointerdown', onPointerDown);
  renderer.domElement.addEventListener('pointerup', onPointerUp);

  if (modelUrl) {
    new GLTFLoader().load(
      modelUrl,
      (gltf) => {
        current = gltf.scene;
        scene.add(current);
        fitObject(current);
        parts = collectParts(current);
        inst.parts = parts;
        inst.current = current;
      },
      undefined,
      () => {
        current = makePlaceholder();
        scene.add(current);
        parts = collectParts(current);
        inst.parts = parts;
        inst.current = current;
      },
    );
  } else {
    current = makePlaceholder();
    scene.add(current);
    parts = collectParts(current);
    inst.parts = parts;
    inst.current = current;
  }

  const hint = document.createElement('div');
  hint.style.cssText = 'position:absolute;left:12px;bottom:10px;color:#e0c0b4;font-size:12px;pointer-events:none';
  hint.textContent = modelUrl ? t('viewer.modelHint') : t('viewer.placeholderHint');
  el.style.position = 'relative';
  el.appendChild(hint);

  instances.set(el, inst);
  el.__siluViewer = inst;

  const onResize = () => {
    const r = el.getBoundingClientRect();
    camera.aspect = r.width / r.height;
    camera.updateProjectionMatrix();
    renderer.setSize(r.width, r.height);
  };
  window.addEventListener('resize', onResize);

  (function loop() {
    controls.update();
    if (current && !modelUrl) current.rotation.y += 0.004;
    renderer.render(scene, camera);
    requestAnimationFrame(loop);
  })();
}

window.SiluViewer = { mount, setExplode, restoreAll, setInteractive };
document.dispatchEvent(new CustomEvent('silu-viewer-ready'));
