/* ===== 共创社区：登录用户论坛发帖，可附上工坊模型 ===== */

let posts = [];
let models = [];

function fmtTime(ts) {
  return new Date(ts).toLocaleString(currentLang());
}

function renderComposer() {
  const logged = isLoggedIn();
  document.getElementById('post-form').hidden = !logged;
  document.getElementById('composer-login').hidden = logged;
}

async function loadModels() {
  const data = await api('/api/models');
  models = data.items || [];
  const sel = document.getElementById('post-model');
  sel.innerHTML =
    `<option value="">${t('community.noModel')}</option>` +
    models.map((m) => `<option value="${m.id}">${escapeHtml(m.title)}</option>`).join('');
}

async function loadPosts() {
  const data = await api('/api/forum/posts');
  posts = data.items || [];
  const box = document.getElementById('posts-list');
  if (!posts.length) {
    box.innerHTML = `<p class="forum-empty">${t('community.noPost')}</p>`;
    return;
  }
  box.innerHTML = posts
    .map((p) => {
      const roleLabel = p.role === 'expert' ? t('account.expert') : t('account.creator');
      const model = p.modelTitle
        ? `<a class="forum-post-model" href="exhibit.html?model=${encodeURIComponent(p.modelId)}">${escapeHtml(p.modelTitle)}</a>`
        : '';
      return `
        <article class="forum-post">
          <div class="forum-post-head">
            <span class="forum-post-author">${escapeHtml(p.username)}
              <span class="meta">${roleLabel} · ${fmtTime(p.createdAt)}</span>
            </span>
          </div>
          <div class="forum-post-body">${escapeHtml(p.content)}</div>
          ${model}
        </article>`;
    })
    .join('');
}

function bindSubmit() {
  const form = document.getElementById('post-form');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const box = document.getElementById('post-result');
    const content = document.getElementById('post-content').value.trim();
    const modelId = document.getElementById('post-model').value;
    if (!content) { box.textContent = t('community.emptyPost'); return; }
    try {
      await api('/api/forum/posts', {
        method: 'POST',
        body: JSON.stringify({ content, modelId }),
      });
      form.reset();
      box.textContent = '';
      await loadPosts();
    } catch (err) { box.textContent = err.message; }
  });
}

async function init() {
  renderComposer();
  bindSubmit();
  await Promise.all([loadModels(), loadPosts()]);
}

document.addEventListener('DOMContentLoaded', () => init().catch((e) => alert(e.message)));

document.addEventListener('langchange', () => {
  Promise.all([loadModels(), loadPosts()]).catch(() => {});
});
