/* ===== 文物拆装与技艺演示：Tab / 智能拆解（Tripo 分割）/ 技艺视频检索 ===== */

let asset = null;
let activeTab = 'overall';
let studioModels = [];
let segmentTimer = null;

function qs(name) {
  return new URLSearchParams(location.search).get(name);
}

function renderHeader() {
  if (!asset) return;
  document.getElementById('exhibit-title').textContent = asset.title;
  const parts = [asset.country, asset.region, asset.dynasty].filter(Boolean);
  document.getElementById('exhibit-origin').textContent =
    `${parts.join(' · ')} ｜ ${asset.types.join(' · ')}`;
}

function bindTabs() {
  document.getElementById('exhibit-tabs').querySelectorAll('button').forEach((btn) =>
    btn.addEventListener('click', () => {
      activeTab = btn.dataset.tab;
      document.querySelectorAll('#exhibit-tabs button').forEach((b) => b.classList.toggle('active', b === btn));
      renderPanel();
    }),
  );
}

function panelOverall() {
  const parts = asset.layers.length ? asset.layers : [{ name: t('overall.unit'), desc: asset.summary }];
  return `
    <h3>${t('tab.overall')}</h3>
    <p>${escapeHtml(asset.summary)}</p>
    <h4 style="margin:16px 0 8px;color:var(--muted);font-size:13px">${t('overall.hintParts')}</h4>
    ${parts.map((p, i) => `
      <div class="layer-row" data-part="${i}" style="cursor:pointer">
        <div class="meta"><span>${escapeHtml(p.name)}</span><span style="color:var(--muted);font-size:12px">${t('overall.clickExpand')}</span></div>
        <div class="caption-box" id="part-desc-${i}" style="display:none;margin-top:6px">${escapeHtml(p.desc)}</div>
      </div>`).join('')}
  `;
}

function panelExplode() {
  // 工坊生成模型：走 Tripo 智能拆解，分割完成后在预览中点选 / 合并 / 复位部件
  if (asset.isStudio) {
    if (asset.segmentUrl) {
      return `
        <h3>${t('tab.explode')}</h3>
        <p style="color:var(--muted);font-size:13px">${t('exhibit.segmentDone')}</p>
        <p style="color:var(--muted);font-size:13px;margin:10px 0">${t('exhibit.partHint')}</p>
        <div class="translate-actions" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <button class="btn sm" id="btn-restore">${t('exhibit.restore')}</button>
          <span id="part-status" style="color:var(--muted);font-size:12px">${t('exhibit.partEmpty')}</span>
        </div>`;
    }
    return `
      <h3>${t('tab.explode')}</h3>
      <p style="color:var(--muted);font-size:13px">${t('exhibit.segmentDesc')}</p>
      <button class="btn sm" id="btn-segment">${t('exhibit.segment')}</button>
      <div id="segment-status" class="mock-tip" style="margin-top:8px"></div>`;
  }

  if (!asset.layers.length) {
    return `<h3>${t('tab.explode')}</h3><p class="mock-tip">${t('explode.noLayers')}</p>`;
  }
  return `
    <h3>${t('tab.explode')}</h3>
    <p style="color:var(--muted);font-size:13px">${t('explode.layerHint')}</p>
    ${asset.layers.map((l, i) => `
      <div class="layer-row">
        <div class="meta"><span>${escapeHtml(l.name)}</span><span style="color:var(--muted);font-size:12px">${t('explode.layer', { n: i + 1 })}</span></div>
        <input type="range" min="0" max="100" value="${100 - i * 18}" data-layer="${i}" style="width:100%" />
        <div class="caption-box" style="margin-top:6px">${escapeHtml(l.desc)}</div>
      </div>`).join('')}
  `;
}

function panelCraft() {
  const steps = asset.craftSteps || [];
  return `
    <h3>${t('tab.craft')}</h3>
    <div class="step-list">
      ${steps.map((s, i) => `
        <div class="step">
          <div class="no">${i + 1}</div>
          <div><strong>${escapeHtml(s.name)}</strong><div style="color:var(--muted);font-size:13px">${escapeHtml(s.desc)}</div></div>
        </div>`).join('')}
    </div>
    <div style="margin-top:18px">
      <h4 style="margin:0 0 10px">${t('video.related')}</h4>
      <div id="related-video"><div class="mock-tip">${t('video.none')}</div></div>
    </div>
  `;
}

function renderPanel() {
  const panel = document.getElementById('exhibit-panel');
  if (!asset) { panel.innerHTML = `<p class="mock-tip">${t('exhibit.notFound')}</p>`; return; }
  if (activeTab === 'overall') panel.innerHTML = panelOverall();
  else if (activeTab === 'explode') panel.innerHTML = panelExplode();
  else panel.innerHTML = panelCraft();

  panel.querySelectorAll('[data-part]').forEach((row) =>
    row.addEventListener('click', () => {
      const desc = document.getElementById(`part-desc-${row.dataset.part}`);
      desc.style.display = desc.style.display === 'none' ? 'block' : 'none';
    }),
  );

  const segBtn = document.getElementById('btn-segment');
  if (segBtn) segBtn.addEventListener('click', startSegment);

  const restoreBtn = document.getElementById('btn-restore');
  if (restoreBtn) restoreBtn.addEventListener('click', doRestore);

  panel.querySelectorAll('input[type=range][data-layer]').forEach((slider) =>
    slider.addEventListener('input', () => applyExplode(Number(slider.value) / 100)),
  );

  if (activeTab === 'craft') loadRelatedVideo();
  if (activeTab === 'overall' || activeTab === 'explode') {
    mountViewer();
    wirePartInteraction();
  }
}

/** 预览部件点选 / 合并 / 复位状态回写到面板 */
function wirePartInteraction() {
  const mount = document.getElementById('viewer');
  const inst = mount && mount.__siluViewer;
  if (!inst) return;
  const interactive = activeTab === 'explode' && asset?.isStudio && !!asset.segmentUrl;
  window.SiluViewer.setInteractive(inst, interactive);
  inst.onInteraction = (payload) => {
    const el = document.getElementById('part-status');
    if (!el) return;
    if (payload.type === 'select') {
      el.textContent = t('exhibit.partSelected', { name: payload.name });
    } else if (payload.type === 'merged') {
      el.textContent = t('exhibit.partMerged', {
        a: payload.parts[0] || '',
        b: (payload.parts.slice(1) || []).join(' + '),
      });
    } else {
      el.textContent = t('exhibit.partEmpty');
    }
  };
}

function doRestore() {
  const mount = document.getElementById('viewer');
  const inst = mount && mount.__siluViewer;
  if (inst && window.SiluViewer) window.SiluViewer.restoreAll(inst);
}

function mountViewer(urlOverride) {
  const mount = document.getElementById('viewer');
  if (!mount) return;
  // 拆装标签下优先展示智能拆解后的部件模型；其余视图展示原始模型
  const url = urlOverride || (activeTab === 'explode' && asset?.segmentUrl) || asset?.modelUrl || null;
  const doMount = () => window.SiluViewer && window.SiluViewer.mount(mount, url);
  if (window.SiluViewer) doMount();
  else document.addEventListener('silu-viewer-ready', doMount, { once: true });
}

function applyExplode(factor) {
  const mount = document.getElementById('viewer');
  const inst = mount && mount.__siluViewer;
  if (inst && window.SiluViewer) window.SiluViewer.setExplode(inst, factor);
}

function setExportAvailable() {
  const btn = document.getElementById('btn-export-exhibit');
  if (!btn) return;
  if (asset && asset.id && asset.modelUrl) {
    btn.hidden = false;
    btn.onclick = async () => {
      try {
        const blob = await fetchBlob(`/api/models/${asset.id}/download`);
        const base = String(asset.title || 'model').replace(/\.[a-z0-9]+$/i, '');
        await saveBlob(blob, `${base}.glb`, '.glb');
      } catch (e) {
        setSegmentStatus(`${t('exhibit.segmentFailed')}：${e.message}`);
      }
    };
  } else {
    btn.hidden = true;
    btn.onclick = null;
  }
}

function setSegmentStatus(text) {
  const el = document.getElementById('segment-status');
  if (el) el.textContent = text;
}

async function startSegment() {
  if (!asset?.modelUrl) return;
  setSegmentStatus(t('exhibit.segmenting'));
  try {
    const created = await api('/api/tripo/segment', {
      method: 'POST',
      body: JSON.stringify({ input: asset.modelUrl }),
    });
    pollSegment(created.task_id, created.mock);
  } catch (e) {
    setSegmentStatus(`${t('exhibit.segmentFailed')}：${e.message}`);
  }
}

function pollSegment(id, mock) {
  if (segmentTimer) clearInterval(segmentTimer);
  let fails = 0;
  segmentTimer = setInterval(async () => {
    let task;
    try {
      task = await api(`/api/tripo/tasks/${id}`);
      fails = 0;
    } catch (e) {
      fails += 1;
      if (fails >= 8) {
        clearInterval(segmentTimer);
        setSegmentStatus(`${t('exhibit.segmentFailed')}：${e.message}`);
      }
      return;
    }
    setSegmentStatus(`${t('exhibit.segmenting')} ${task.status} ${task.progress ?? ''}`);
    if (task.status === 'success') {
      clearInterval(segmentTimer);
      const out = task.output || {};
      const segUrl = out.model_url || (out.model && out.model.url) || null;
      if (segUrl) {
        asset.segmentUrl = segUrl;
        renderPanel();
      } else {
        setSegmentStatus(t('exhibit.segmentFailed'));
      }
    } else if (['failed', 'cancelled', 'expired'].includes(task.status)) {
      clearInterval(segmentTimer);
      setSegmentStatus(t('exhibit.segmentFailed'));
    }
  }, 1200);
}

async function loadRelatedVideo() {
  const box = document.getElementById('related-video');
  if (!box) return;
  try {
    const data = await api(`/api/video/search?assetId=${encodeURIComponent(asset.id)}`);
    if (data.found && data.videoUrl) {
      box.innerHTML = `<video src="${data.videoUrl}" controls style="width:100%;border-radius:12px"></video>`;
    } else {
      box.innerHTML = `<div class="mock-tip">${t('video.none')}</div>`;
    }
  } catch {
    box.innerHTML = `<div class="mock-tip">${t('video.none')}</div>`;
  }
}

function studioAsset(m) {
  return {
    id: m.id,
    title: m.title,
    country: '@' + m.username,
    region: m.source,
    dynasty: '',
    types: ['3D数字模型'],
    summary: t('exhibit.studioSummary'),
    layers: [],
    craftSteps: [],
    caption: { zh: m.title },
    modelUrl: m.modelUrl,
    segmentUrl: null,
    isStudio: true,
  };
}

async function loadStudioModels() {
  const box = document.getElementById('studio-models-list');
  if (!box) return;
  const data = await api('/api/models');
  studioModels = data.items || [];
  if (!studioModels.length) {
    box.innerHTML = `<p class="mock-tip">${t('exhibit.noStudioModel')}</p>`;
    return;
  }
  box.innerHTML = studioModels
    .map((m) => `
      <div class="layer-row" data-model="${m.id}" style="cursor:pointer">
        <div class="meta">
          <span>${escapeHtml(m.title)}</span>
          <span style="color:var(--muted);font-size:12px">@${escapeHtml(m.username)} · ${new Date(m.createdAt).toLocaleString(currentLang())}</span>
        </div>
      </div>`)
    .join('');
  box.querySelectorAll('[data-model]').forEach((row) =>
    row.addEventListener('click', () => {
      location.href = `exhibit.html?model=${encodeURIComponent(row.dataset.model)}`;
    }),
  );
}

document.addEventListener('DOMContentLoaded', async () => {
  bindTabs();
  const modelId = qs('model');
  const assetId = qs('id');
  try {
    if (modelId) {
      const data = await api('/api/models');
      const m = (data.items || []).find((x) => x.id === modelId);
      if (!m) throw new Error(t('exhibit.notFound'));
      asset = studioAsset(m);
      renderHeader();
      setExportAvailable();
      renderPanel();
    } else if (assetId) {
      const data = await api(`/api/assets/${encodeURIComponent(assetId || '')}`);
      asset = data.item;
      renderHeader();
      setExportAvailable();
      renderPanel();
    }
  } catch (e) {
    document.getElementById('exhibit-panel').innerHTML = `<p class="mock-tip">${escapeHtml(e.message)}</p>`;
  }
  loadStudioModels().catch(() => {});
});

document.addEventListener('langchange', () => {
  if (asset) { renderHeader(); renderPanel(); }
  loadStudioModels().catch(() => {});
});
