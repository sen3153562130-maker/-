/* ===== 数字非遗资产库：检索 / 筛选 / 卡片网格 ===== */

const state = {
  q: '',
  category: '',
  country: '',
  type: '',
};

/* 内部 value 为后端资产库存储的原值（中文），label 为界面本地化文案 */
const CATEGORIES = [
  { value: '', label: 'filter.all' },
  { value: '陶瓷', label: 'cat.ceramic' },
  { value: '织锦', label: 'cat.textile' },
  { value: '木作', label: 'cat.wood' },
  { value: '民俗', label: 'cat.folk' },
];
const COUNTRIES = [
  { value: '中国', label: 'country.cn' },
  { value: '印度尼西亚', label: 'country.id' },
  { value: '马来西亚', label: 'country.my' },
  { value: '澳大利亚', label: 'country.au' },
];
const TYPES = [
  { value: '3D数字模型', label: 'type.model' },
  { value: '文物拆装演示', label: 'type.assembly' },
  { value: '非遗技艺演示', label: 'type.craft' },
  { value: '图文', label: 'type.text' },
  { value: '多语种展签', label: 'type.label' },
];

function renderCategoryTabs() {
  const box = document.getElementById('category-tabs');
  box.innerHTML = CATEGORIES.map(
    (c) => `<button data-cat="${c.value}" class="${c.value === state.category ? 'active' : ''}">${t(c.label)}</button>`,
  ).join('');
  box.querySelectorAll('button').forEach((b) =>
    b.addEventListener('click', () => { state.category = b.dataset.cat; renderCategoryTabs(); load(); }),
  );
}

function renderFilterGroup(containerId, options, key) {
  const box = document.getElementById(containerId);
  box.innerHTML = options.map(
    (o) => `<label><input type="radio" name="${key}" value="${o.value}" ${state[key] === o.value ? 'checked' : ''} /> ${t(o.label)}</label>`,
  ).join('') + `<label><input type="radio" name="${key}" value="" ${state[key] === '' ? 'checked' : ''} /> ${t('filter.any')}</label>`;
  box.querySelectorAll('input').forEach((r) =>
    r.addEventListener('change', () => { state[key] = r.value; load(); }),
  );
}

function labelOf(value, options) {
  const hit = options.find((o) => o.value === value);
  return hit ? t(hit.label) : escapeHtml(value);
}

function cardHtml(a) {
  const has3D = a.types.includes('3D数字模型');
  return `
    <a class="card" href="exhibit.html?id=${encodeURIComponent(a.id)}">
      <div class="cover" style="${coverStyle(a.cover)}">
        ${has3D ? '<span class="three-tag">3D</span>' : ''}
        <span>${labelOf(a.category, CATEGORIES)}</span>
      </div>
      <div class="body">
        <h3>${escapeHtml(a.title)}</h3>
        <div class="origin">${labelOf(a.country, COUNTRIES)} · ${escapeHtml(a.region)} · ${escapeHtml(a.dynasty)}</div>
        <div class="tags">
          ${a.types.map((ty) => `<span class="badge muted">${labelOf(ty, TYPES)}</span>`).join('')}
        </div>
      </div>
    </a>`;
}

async function load() {
  const params = new URLSearchParams();
  if (state.q) params.set('q', state.q);
  if (state.category) params.set('category', state.category);
  if (state.country) params.set('country', state.country);
  if (state.type) params.set('type', state.type);

  const data = await api(`/api/assets?${params.toString()}`);
  const grid = document.getElementById('asset-grid');
  document.getElementById('result-count').textContent = t('result.count', { n: data.total });
  document.getElementById('empty-tip').style.display = data.items.length ? 'none' : 'block';
  grid.innerHTML = data.items.map(cardHtml).join('');
}

function bindEvents() {
  const input = document.getElementById('search-input');
  const doSearch = () => { state.q = input.value.trim(); load(); };
  document.getElementById('search-btn').addEventListener('click', doSearch);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') doSearch(); });
}

function renderFilters() {
  renderCategoryTabs();
  renderFilterGroup('filter-country', COUNTRIES, 'country');
  renderFilterGroup('filter-type', TYPES, 'type');
}

document.addEventListener('DOMContentLoaded', () => {
  renderFilters();
  bindEvents();
  load().catch((e) => { document.getElementById('asset-grid').textContent = e.message; });
});

document.addEventListener('langchange', () => {
  renderFilters();
  load().catch(() => {});
});
