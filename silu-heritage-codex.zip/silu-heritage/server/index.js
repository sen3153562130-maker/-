'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const tripo = require('./adapters/tripo');
const ark = require('./adapters/ark');
const auth = require('./adapters/auth');
const store = require('./store');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const ASSETS_FILE = path.join(__dirname, 'data', 'assets.json');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.glb': 'model/gltf-binary',
  '.gltf': 'model/gltf+json',
  '.mp4': 'video/mp4',
  '.ico': 'image/x-icon',
};

function readAssets() {
  return JSON.parse(fs.readFileSync(ASSETS_FILE, 'utf8'));
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (c) => { raw += c; if (raw.length > 5e6) req.destroy(); });
    req.on('end', () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch { reject(new Error('请求体不是合法 JSON')); }
    });
    req.on('error', reject);
  });
}

function bearerToken(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : null;
}

async function handleApi(req, res, url) {
  const p = url.pathname;

  // ---- 账户：注册 / 登录 / 会话 ----
  if (p === '/api/auth/register' && req.method === 'POST') {
    const body = await readBody(req);
    const user = auth.createUser(body);
    const token = auth.issueSession(user);
    return sendJson(res, 200, { token, user });
  }
  if (p === '/api/auth/login' && req.method === 'POST') {
    const body = await readBody(req);
    const user = auth.verify(body.username, body.password);
    const token = auth.issueSession(user);
    return sendJson(res, 200, { token, user });
  }
  if (p === '/api/auth/logout' && req.method === 'POST') {
    auth.destroySession(bearerToken(req));
    return sendJson(res, 200, { ok: true });
  }
  if (p === '/api/auth/me' && req.method === 'GET') {
    const user = auth.resolveSession(bearerToken(req));
    if (!user) return sendJson(res, 401, { error: '未登录' });
    return sendJson(res, 200, { user });
  }

  // ---- 工坊生成模型库 ----
  if (p === '/api/models' && req.method === 'GET') {
    const models = store.readJSON('models.json', []);
    return sendJson(res, 200, { items: models });
  }
  if (p === '/api/models' && req.method === 'POST') {
    const user = auth.resolveSession(bearerToken(req));
    const body = await readBody(req);
    const models = store.readJSON('models.json', []);
    const record = {
      id: 'm-' + Date.now().toString(36),
      userId: user ? user.id : null,
      username: user ? user.username : 'visitor',
      role: user ? user.role : 'creator',
      title: String(body.title || '未命名模型').slice(0, 60),
      source: body.source || 'studio',
      modelUrl: body.modelUrl || null,
      views: body.views || null,
      createdAt: Date.now(),
    };
    models.unshift(record);
    store.writeJSON('models.json', models);
    return sendJson(res, 200, { item: record });
  }

  // ---- 工坊模型导出：代理远程 GLB，避免跨域并强制下载 ----
  const modelDownloadMatch = p.match(/^\/api\/models\/([\w-]+)\/download$/);
  if (modelDownloadMatch && req.method === 'GET') {
    const models = store.readJSON('models.json', []);
    const record = models.find((m) => m.id === modelDownloadMatch[1]);
    if (!record) return sendJson(res, 404, { error: '模型不存在' });
    if (!record.modelUrl) return sendJson(res, 400, { error: '该模型暂无可导出的模型文件' });
    let remote;
    try { remote = new URL(record.modelUrl); } catch { return sendJson(res, 400, { error: '模型地址无效' }); }
    if (remote.protocol !== 'https:' || !remote.hostname.endsWith('tripo3d.com')) {
      return sendJson(res, 400, { error: '模型地址不受支持' });
    }
    const upstream = await fetch(remote.toString(), { redirect: 'follow' });
    if (!upstream.ok) return sendJson(res, 502, { error: `模型文件下载失败（HTTP ${upstream.status}）` });
    const buf = Buffer.from(await upstream.arrayBuffer());
    const baseName = String(record.title || 'model').replace(/\.[a-z0-9]+$/i, '');
    const safeName = baseName.replace(/[^\w\u4e00-\u9fa5-]+/g, '_').slice(0, 60) || 'model';
    res.writeHead(200, {
      'Content-Type': 'model/gltf-binary',
      'Content-Length': buf.length,
      'Content-Disposition': `attachment; filename="${safeName}.glb"`,
      'Cache-Control': 'no-store',
    });
    return res.end(buf);
  }

  // ---- 论坛帖子 ----
  if (p === '/api/forum/posts' && req.method === 'GET') {
    const posts = store.readJSON('posts.json', []);
    return sendJson(res, 200, { items: posts });
  }
  if (p === '/api/forum/posts' && req.method === 'POST') {
    const user = auth.resolveSession(bearerToken(req));
    if (!user) return sendJson(res, 401, { error: '请先登录后发言' });
    const body = await readBody(req);
    const content = String(body.content || '').trim();
    if (!content) return sendJson(res, 400, { error: '发言内容不能为空' });
    const posts = store.readJSON('posts.json', []);
    let modelTitle = null;
    if (body.modelId) {
      const models = store.readJSON('models.json', []);
      const m = models.find((x) => x.id === body.modelId);
      if (m) modelTitle = m.title;
    }
    const post = {
      id: 'p-' + Date.now().toString(36),
      userId: user.id,
      username: user.username,
      role: user.role,
      content: content.slice(0, 2000),
      modelId: body.modelId || null,
      modelTitle,
      createdAt: Date.now(),
    };
    posts.unshift(post);
    store.writeJSON('posts.json', posts);
    return sendJson(res, 200, { item: post });
  }

  // ---- 健康 / 能力状态 ----
  if (p === '/api/health' && req.method === 'GET') {
    return sendJson(res, 200, { tripo: config.tripo.enabled, ark: config.ark.enabled, mock: !config.tripo.enabled || !config.ark.enabled });
  }

  // ---- 资产库 ----
  if (p === '/api/assets' && req.method === 'GET') {
    let assets = readAssets();
    const q = url.searchParams.get('q') || '';
    const category = url.searchParams.get('category') || '';
    const country = url.searchParams.get('country') || '';
    const type = url.searchParams.get('type') || '';
    const status = url.searchParams.get('status') || '';

    if (category && category !== '全部') assets = assets.filter((a) => a.category === category);
    if (country) assets = assets.filter((a) => a.country === country);
    if (type) assets = assets.filter((a) => a.types.includes(type));
    if (status) assets = assets.filter((a) => a.status === status);

    if (q) {
      const searched = await ark.searchAssets(q, assets);
      assets = searched.results;
    }
    return sendJson(res, 200, { total: assets.length, items: assets });
  }

  const assetMatch = p.match(/^\/api\/assets\/([\w-]+)$/);
  if (assetMatch && req.method === 'GET') {
    const asset = readAssets().find((a) => a.id === assetMatch[1]);
    if (!asset) return sendJson(res, 404, { error: '资产不存在' });
    return sendJson(res, 200, { item: asset });
  }

  // ---- Tripo 3D 建模 ----
  if (p === '/api/tripo/upload' && req.method === 'POST') {
    const body = await readBody(req);
    if (!body.dataB64) return sendJson(res, 400, { error: '缺少文件数据 dataB64' });
    const buffer = Buffer.from(body.dataB64, 'base64');
    const result = await tripo.uploadFile({
      name: body.name || 'upload.bin',
      mime: body.mime || 'application/octet-stream',
      buffer,
    });
    return sendJson(res, 200, result);
  }
  if (p === '/api/tripo/image-to-model' && req.method === 'POST') {
    const body = await readBody(req);
    if (!body.input) return sendJson(res, 400, { error: '缺少 input（图片 URL 或 file_token）' });
    const result = await tripo.imageToModel(body.input, body.options || {});
    return sendJson(res, 200, result);
  }
  if (p === '/api/tripo/multiview-to-model' && req.method === 'POST') {
    const body = await readBody(req);
    if (!Array.isArray(body.inputs) || body.inputs.length === 0) {
      return sendJson(res, 400, { error: '缺少 inputs（前 / 左 / 后 / 右视图数组）' });
    }
    const hasFront = body.inputs.some((v) => v && v.front);
    const viewCount = body.inputs.filter((v) => v && (v.front || v.left || v.back || v.right)).length;
    if (!hasFront) return sendJson(res, 400, { error: '必须提供正面视图（front）' });
    if (viewCount < 2) return sendJson(res, 400, { error: '至少需要 2 张有效视图图片' });
    const result = await tripo.multiviewToModel(body.inputs, body.options || {});
    return sendJson(res, 200, result);
  }
  if (p === '/api/tripo/image-to-multiview' && req.method === 'POST') {
    const body = await readBody(req);
    if (!body.input) return sendJson(res, 400, { error: '缺少 input（图片 file_token）' });
    const result = await tripo.imageToMultiview(body.input, body.options || {});
    return sendJson(res, 200, result);
  }
  if (p === '/api/tripo/segment' && req.method === 'POST') {
    const body = await readBody(req);
    if (!body.input) return sendJson(res, 400, { error: '缺少 input（模型 task_id / file_token / GLB 地址）' });
    const result = await tripo.segmentModel(body.input, body.options || {});
    return sendJson(res, 200, result);
  }
  const tripoTaskMatch = p.match(/^\/api\/tripo\/tasks\/([\w-]+)$/);
  if (tripoTaskMatch && req.method === 'GET') {
    const task = await tripo.getTask(tripoTaskMatch[1]);
    return sendJson(res, 200, task);
  }

  // ---- 豆包方舟：翻译 / 讲解稿 / 搜索 / 视频 ----
  if (p === '/api/ark/translate' && req.method === 'POST') {
    const body = await readBody(req);
    if (!body.text) return sendJson(res, 400, { error: '缺少 text' });
    const result = await ark.translate(body.text, body.targets || ['en', 'id', 'ms', 'th'], body.glossary || {});
    return sendJson(res, 200, result);
  }
  if (p === '/api/ark/script' && req.method === 'POST') {
    const body = await readBody(req);
    if (!body.topic) return sendJson(res, 400, { error: '缺少 topic' });
    const result = await ark.generateScript(body.topic, body.context || '');
    return sendJson(res, 200, result);
  }
  if (p === '/api/ark/search' && req.method === 'GET') {
    const result = await ark.searchAssets(url.searchParams.get('q') || '', readAssets());
    return sendJson(res, 200, { total: result.results.length, items: result.results, mock: result.mock });
  }
  if (p === '/api/ark/multiview' && req.method === 'POST') {
    const body = await readBody(req);
    if (!body.imageUrl) return sendJson(res, 400, { error: '缺少 imageUrl' });
    const result = await ark.generateMultiview(body.imageUrl);
    return sendJson(res, 200, result);
  }
  if (p === '/api/ark/vision' && req.method === 'POST') {
    const body = await readBody(req);
    if (!body.imageUrl) return sendJson(res, 400, { error: '缺少 imageUrl' });
    const result = await ark.analyzeImage(body.imageUrl, body.question || '');
    return sendJson(res, 200, result);
  }

  // 图片代理：拉取上游 TOS 图片为 Blob，供前端自选目录保存（避免跨域）
  if (p === '/api/ark/proxy' && req.method === 'GET') {
    const target = url.searchParams.get('url') || '';
    let remote;
    try { remote = new URL(target); } catch { return sendJson(res, 400, { error: '图片地址无效' }); }
    const okHost = remote.hostname.endsWith('volces.com') || remote.hostname.endsWith('tripo3d.com');
    if (remote.protocol !== 'https:' || !okHost) return sendJson(res, 400, { error: '图片地址不受支持' });
    const upstream = await fetch(remote.toString(), { redirect: 'follow' });
    if (!upstream.ok) return sendJson(res, 502, { error: `图片下载失败（HTTP ${upstream.status}）` });
    const buf = Buffer.from(await upstream.arrayBuffer());
    res.writeHead(200, {
      'Content-Type': upstream.headers.get('content-type') || 'image/png',
      'Content-Length': buf.length,
      'Cache-Control': 'no-store',
    });
    return res.end(buf);
  }

  // 视频检索：按资产（或后续按上传图片）匹配已有影像，无匹配则不返回视频
  if (p === '/api/video/search' && req.method === 'GET') {
    const assetId = url.searchParams.get('assetId') || '';
    const imageUrl = url.searchParams.get('imageUrl') || '';
    const assets = readAssets();
    let matched = null;
    if (assetId) matched = assets.find((a) => a.id === assetId) || null;
    // 图片检索预留位：后续可接视觉向量以图搜视频；v1 仅按资产关联
    const videoUrl = matched?.videoUrl || null;
    return sendJson(res, 200, { found: Boolean(videoUrl), videoUrl, assetId: matched?.id || null, imageUrl });
  }

  return sendJson(res, 404, { error: '接口不存在' });
}

function serveStatic(req, res, url) {
  let filePath = path.join(PUBLIC_DIR, decodeURIComponent(url.pathname));
  if (url.pathname === '/' ) filePath = path.join(PUBLIC_DIR, 'index.html');
  // 防目录穿越
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403); return res.end('Forbidden');
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('404 Not Found');
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    return serveStatic(req, res, url);
  } catch (e) {
    console.error(e);
    return sendJson(res, e.status || 500, { error: e.message || '服务器内部错误' });
  }
});

server.listen(config.port, '0.0.0.0', () => {
  console.log(`丝路遗珍平台已启动：http://localhost:${config.port}`);
  console.log(`Tripo API：${config.tripo.enabled ? '已接入' : 'Mock 模式'}；豆包方舟：${config.ark.enabled ? '已接入' : 'Mock 模式'}`);
});
