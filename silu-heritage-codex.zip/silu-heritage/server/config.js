'use strict';
const fs = require('fs');
const path = require('path');

/** 轻量 .env 读取（零依赖）：不覆盖已存在的环境变量 */
function loadEnv() {
  const envPath = path.join(__dirname, '..', '.env');
  if (fs.existsSync(envPath)) {
    const text = fs.readFileSync(envPath, 'utf8');
    for (const rawLine of text.split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith('#')) continue;
      const eq = line.indexOf('=');
      if (eq < 0) continue;
      const key = line.slice(0, eq).trim();
      const value = line.slice(eq + 1).trim();
      if (!(key in process.env)) process.env[key] = value;
    }
  }
}

loadEnv();

const config = {
  port: Number(process.env.PORT || 3000),
  tripo: {
    apiKey: process.env.TRIPO_API_KEY || '',
    baseUrl: process.env.TRIPO_BASE_URL || 'https://openapi.tripo3d.com/v3',
    model: process.env.TRIPO_MODEL || 'v3.1-20260211',
  },
  ark: {
    apiKey: process.env.ARK_API_KEY || '',
    baseUrl: process.env.ARK_BASE_URL || 'https://ark.cn-beijing.volces.com/api/v3',
    chatModel: process.env.ARK_CHAT_MODEL || 'doubao-seed-2-1-pro-260915',
    translationModel: process.env.ARK_TRANSLATION_MODEL || 'doubao-seed-translation-250915',
    embeddingModel: process.env.ARK_EMBEDDING_MODEL || 'doubao-embedding-vision-251215',
    visionModel: process.env.ARK_VISION_MODEL || '',
    multiviewModel: process.env.ARK_MULTIVIEW_MODEL || '',
  },
};

config.tripo.enabled = Boolean(config.tripo.apiKey);
if (!config.ark.visionModel) config.ark.visionModel = config.ark.chatModel;
if (!config.ark.multiviewModel) config.ark.multiviewModel = config.ark.chatModel;
config.ark.enabled = Boolean(config.ark.apiKey);

module.exports = config;
