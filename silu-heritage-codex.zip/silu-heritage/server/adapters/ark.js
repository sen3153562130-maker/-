'use strict';
const config = require('../config');
const { requestJson } = require('./http');

const BASE = config.ark.baseUrl;

const LANG_NAMES = { zh: '中文', en: '英语', id: '印尼语', ms: '马来语', th: '泰语' };

/** 通用对话补全 */
async function chat(messages, model) {
  const data = await requestJson(`${BASE}/chat/completions`, {
    method: 'POST',
    apiKey: config.ark.apiKey,
    body: {
      model: model || config.ark.chatModel,
      messages,
      temperature: 0.3,
    },
  });
  return data.choices?.[0]?.message?.content || '';
}

/** Responses API（翻译等仅支持 Responses 的模型使用） */
async function responses(input, model, extra = {}) {
  const data = await requestJson(`${BASE}/responses`, {
    method: 'POST',
    apiKey: config.ark.apiKey,
    body: { model, input, ...extra },
  });
  let text = '';
  for (const item of data.output || []) {
    if (item.type !== 'message') continue;
    for (const c of item.content || []) {
      if (c.type === 'output_text') text += c.text || '';
      else if (typeof c.text === 'string') text += c.text;
    }
  }
  return (text || data.output_text || '').trim();
}

/**
 * 多语翻译（术语库约束）
 * @param {string} text 待译原文（中文）
 * @param {string[]} targets 目标语种 en/id/ms/th
 * @param {object} glossary 术语对照 {中文: 译文}
 */
async function translate(text, targets = ['en', 'id', 'ms', 'th'], glossary = {}) {
  if (!config.ark.enabled) {
    const out = { zh: text };
    for (const t of targets) out[t] = `[${LANG_NAMES[t] || t}] ${text}（演示译文，接入 ARK_API_KEY 后由豆包翻译模型生成）`;
    return { translations: out, mock: true };
  }

  const translations = { zh: text };
  for (const t of targets) {
    translations[t] = await responses(
      [
        {
          role: 'user',
          content: [
            {
              type: 'input_text',
              text,
              translation_options: { source_language: 'zh', target_language: t },
            },
          ],
        },
      ],
      config.ark.translationModel,
    );
  }
  return { translations, mock: false };
}

/** AI 讲解稿 / 释文初稿 */
async function generateScript(topic, context = '') {
  if (!config.ark.enabled) {
    return {
      script: `【演示讲解稿】围绕「${topic}」展开：首先介绍其产地、年代与工艺特征；其次说明材质、纹饰与文化寓意；最后补充其在丝路文化交流中的位置。（接入 ARK_API_KEY 后由豆包大模型生成完整稿件）`,
      mock: true,
    };
  }
  const content = await chat([
    {
      role: 'system',
      content: '你是非遗文博领域的撰稿人，撰写面向公众的简短展陈讲解稿，语言通俗、准确，避免文物真伪鉴定式表述。',
    },
    { role: 'user', content: `主题：${topic}\n补充信息：${context || '无'}\n请输出 200 字以内的讲解稿，分段：器物概述 / 工艺与纹饰 / 文化价值。` },
  ]);
  return { script: content, mock: false };
}

/** 本地关键词打分（无向量时兜底） */
function keywordScore(asset, query) {
  const fields = [asset.title, asset.country, asset.region, asset.dynasty, asset.category, asset.summary, ...asset.tags, ...asset.types]
    .filter(Boolean)
    .join(' ');
  const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
  let score = 0;
  for (const term of terms) {
    if (fields.toLowerCase().includes(term)) score += 1;
  }
  return score;
}

/** 图片理解（豆包视觉模型）：识别器物特征 / 纹饰 / 工艺 */
async function analyzeImage(imageUrl, question = '请识别这件文物或工艺品的器型、材质、纹饰与可能的年代工艺特征，用中文简要描述。') {
  if (!config.ark.enabled) {
    return {
      analysis: '【演示识别结果】接入 ARK_API_KEY 后，由豆包视觉模型读取图片并输出器型、材质、纹饰与工艺判断。',
      mock: true,
    };
  }
  const content = [
    { type: 'text', text: question },
    { type: 'image_url', image_url: { url: imageUrl } },
  ];
  const text = await chat([
    { role: 'system', content: '你是非遗文博领域的图像分析助手，描述客观准确，不做文物真伪的法定鉴定。' },
    { role: 'user', content },
  ], config.ark.visionModel);
  return { analysis: text, mock: false };
}

/**
 * 资产检索：关键词命中 + （有 Key 时）Embedding 语义重排
 * @param {string} query
 * @param {Array} assets 全量资产
 */
async function searchAssets(query, assets) {
  const q = (query || '').trim();
  if (!q) return { results: assets, mock: !config.ark.enabled };

  let results = assets.map((a) => ({ asset: a, score: keywordScore(a, q) }));
  results = results.filter((r) => r.score > 0);

  if (config.ark.enabled) {
    try {
      const embed = async (text) => {
        const data = await requestJson(`${BASE}/embeddings/multimodal`, {
          method: 'POST',
          apiKey: config.ark.apiKey,
          body: {
            model: config.ark.embeddingModel,
            encoding_format: 'float',
            input: [{ type: 'text', text }],
          },
        });
        return data.data?.[0]?.embedding || [];
      };
      const cosine = (v1, v2) => {
        let dot = 0, n1 = 0, n2 = 0;
        for (let i = 0; i < v1.length; i++) { dot += v1[i] * v2[i]; n1 += v1[i] ** 2; n2 += v2[i] ** 2; }
        return dot / (Math.sqrt(n1) * Math.sqrt(n2) || 1);
      };
      const qVec = await embed(q);
      for (const r of results) {
        const doc = [r.asset.title, r.asset.summary, r.asset.category, r.asset.tags.join(' ')].join(' ');
        const dVec = await embed(doc);
        r.semantic = cosine(qVec, dVec);
      }
      results.sort((a, b) => (b.semantic ?? 0) - (a.semantic ?? 0));
    } catch {
      results.sort((a, b) => b.score - a.score);
    }
  } else {
    results.sort((a, b) => b.score - a.score);
  }

  return { results: results.map((r) => r.asset), mock: !config.ark.enabled };
}

/** 单图生成一张参考视图（方舟图像模型）；未接入 Key 时返回 Mock 占位 */
async function generateMultiview(imageUrl) {
  if (!config.ark.enabled) {
    return { image: null, mock: true };
  }
  const data = await requestJson(`${BASE}/images/generations`, {
    method: 'POST',
    apiKey: config.ark.apiKey,
    body: {
      model: config.ark.multiviewModel,
      prompt: '基于参考图生成同一物体的清晰正视图，背景干净、光照一致、比例一致。',
      image: [imageUrl],
      size: '1024x1024',
      response_format: 'url',
      watermark: false,
    },
  });
  const first = data.data?.[0] || {};
  const url = first.url || first.image_url || null;
  return { image: url, mock: false };
}

module.exports = { translate, generateScript, analyzeImage, searchAssets, chat, generateMultiview };
