'use strict';
const config = require('../config');
const { requestJson } = require('./http');

const BASE = config.tripo.baseUrl;

// ===== Mock 任务 / 文件内存仓库（无 Key 或演示阶段使用）=====
const mockTasks = new Map();
const mockFiles = new Map();
let mockSeq = 0;
let fileSeq = 0;

function makeMockTask(kind, payload) {
  const id = `mock-tripo-${++mockSeq}`;
  mockTasks.set(id, {
    id, kind, payload, status: 'queued', progress: 0, createdAt: Date.now(), mock: true,
  });
  return id;
}

function getMockTask(id) {
  const task = mockTasks.get(id);
  if (!task) return null;
  const elapsed = Date.now() - task.createdAt;
  if (elapsed > 4000 && task.status !== 'success') { task.status = 'success'; task.progress = 100; }
  else if (elapsed > 1500) { task.status = 'running'; task.progress = Math.min(80, Math.floor(elapsed / 50)); }
  return task;
}

/** 构造 multipart/form-data 请求体 */
function buildMultipart(files) {
  const boundary = '----silu' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const f of files) {
    parts.push(Buffer.from(
      `--${boundary}\r\nContent-Disposition: form-data; name="${f.field}"; filename="${f.name}"\r\nContent-Type: ${f.mime}\r\n\r\n`,
    ));
    parts.push(f.buffer, Buffer.from('\r\n'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}

/** 上传图片 / 模型文件，换取 file_token */
async function uploadFile({ name, mime, buffer }) {
  if (!config.tripo.enabled) {
    const token = `mock-file-${++fileSeq}`;
    mockFiles.set(token, { name, mime });
    return { file_token: token, mock: true };
  }
  const { body, contentType } = buildMultipart([{ field: 'file', name, mime, buffer }]);
  const data = await requestJson(`${BASE}/files`, {
    method: 'POST',
    apiKey: config.tripo.apiKey,
    headers: { 'Content-Type': contentType },
    body,
  });
  if (data.code !== 0) throw new Error(data.message || 'Tripo 文件上传失败');
  return { file_token: data.data.file_token, mock: false };
}

/** 单图生成 3D；input 为公网图片 URL 或 file_token */
async function imageToModel(input, options = {}) {
  if (!config.tripo.enabled) {
    const id = makeMockTask('image-to-model', { input, ...options });
    return { task_id: id, mock: true };
  }
  const data = await requestJson(`${BASE}/generation/image-to-model`, {
    method: 'POST',
    apiKey: config.tripo.apiKey,
    body: {
      input,
      model: config.tripo.model,
      texture: true,
      pbr: true,
      enable_image_autofix: options.autofix !== false,
      ...options.extra,
    },
  });
  if (data.code !== 0) throw new Error(data.message || 'Tripo 图生3D任务提交失败');
  return { task_id: data.data.task_id, mock: false };
}

/** 多视图（前 / 左 / 后 / 右）生成 3D；inputs 为 view-key 对象数组 */
async function multiviewToModel(inputs, options = {}) {
  if (!config.tripo.enabled) {
    const id = makeMockTask('multiview-to-model', { inputs, ...options });
    return { task_id: id, mock: true };
  }
  const data = await requestJson(`${BASE}/generation/multiview-to-model`, {
    method: 'POST',
    apiKey: config.tripo.apiKey,
    body: {
      inputs,
      model: config.tripo.model,
      texture: true,
      pbr: true,
      ...options.extra,
    },
  });
  if (data.code !== 0) throw new Error(data.message || 'Tripo 多视图建模任务提交失败');
  return { task_id: data.data.task_id, mock: false };
}

/** 单图生成多视图（前 / 左 / 后 / 右），作为多视图建模的预处理 */
async function imageToMultiview(input, options = {}) {
  if (!config.tripo.enabled) {
    const id = makeMockTask('image-to-multiview', { input, ...options });
    return { task_id: id, mock: true };
  }
  const data = await requestJson(`${BASE}/generation/image-to-multiview`, {
    method: 'POST',
    apiKey: config.tripo.apiKey,
    body: { input, ...options.extra },
  });
  if (data.code !== 0) throw new Error(data.message || 'Tripo 多视图生成任务提交失败');
  return { task_id: data.data.task_id, mock: false };
}

/** 智能拆解：对已有模型（task_id / file_token / 公网 GLB 地址）做部件分割 */
async function segmentModel(input, options = {}) {
  if (!config.tripo.enabled) {
    const id = makeMockTask('mesh-segmentation', { input, ...options });
    return { task_id: id, mock: true };
  }
  // 默认走 v1 几何分割（比 v2 语义分割更快）；options.extra 可覆盖模型版本
  const data = await requestJson(`${BASE}/mesh/segment`, {
    method: 'POST',
    apiKey: config.tripo.apiKey,
    body: { input, model: 'v1.0-20250506', ...options.extra },
  });
  if (data.code !== 0) throw new Error(data.message || 'Tripo 智能拆解任务提交失败');
  return { task_id: data.data.task_id, mock: false };
}

/** 查询任务状态 */
async function getTask(taskId) {
  if (!config.tripo.enabled || String(taskId).startsWith('mock-')) {
    const task = getMockTask(taskId);
    if (!task) {
      const err = new Error('任务不存在');
      err.status = 404;
      throw err;
    }
    const output = task.status === 'success'
      ? task.kind === 'image-to-multiview'
        ? {
            front_view_url: null, left_view_url: null, back_view_url: null, right_view_url: null,
            note: '演示占位：Tripo 返回前 / 左 / 后 / 右视图图片地址',
          }
        : { model_url: null, format: 'glb', note: '演示占位：Tripo 出模后此处返回真实 GLB/GLTF 地址' }
      : null;
    return { id: task.id, status: task.status, progress: task.progress, mock: true, output };
  }
  const data = await requestJson(`${BASE}/tasks/${taskId}`, {
    method: 'GET',
    apiKey: config.tripo.apiKey,
  });
  if (data.code !== 0) throw new Error(data.message || 'Tripo 任务查询失败');
  return {
    id: taskId,
    status: data.data.status,
    progress: data.data.progress ?? null,
    mock: false,
    output: data.data.output || null,
  };
}

module.exports = { uploadFile, imageToModel, multiviewToModel, imageToMultiview, segmentModel, getTask };
