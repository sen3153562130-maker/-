'use strict';

/** 统一请求封装（Node 18+ 全局 fetch）；body 为字符串 / 对象 / Buffer 均可 */
async function requestJson(url, options = {}) {
  const { method = 'GET', headers = {}, body, apiKey } = options;
  const finalHeaders = { Accept: 'application/json', ...headers };
  if (apiKey) finalHeaders.Authorization = `Bearer ${apiKey}`;

  let payload = body;
  if (body != null) {
    if (Buffer.isBuffer(body)) {
      payload = body; // 调用方自行设置 Content-Type（如 multipart）
    } else if (typeof body !== 'string') {
      if (!finalHeaders['Content-Type']) finalHeaders['Content-Type'] = 'application/json';
      payload = JSON.stringify(body);
    } else if (!finalHeaders['Content-Type']) {
      finalHeaders['Content-Type'] = 'application/json';
    }
  }

  const resp = await fetch(url, { method, headers: finalHeaders, body: payload });

  const text = await resp.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { raw: text };
  }
  if (!resp.ok) {
    const message = data && (data.message || data.error?.message) ? data.message || data.error.message : `HTTP ${resp.status}`;
    const err = new Error(message);
    err.status = resp.status;
    err.data = data;
    throw err;
  }
  return data;
}

module.exports = { requestJson };
