'use strict';
const crypto = require('crypto');
const { readJSON, writeJSON } = require('../store');

const USERS_FILE = 'users.json';
// 内存会话表：重启后需重新登录（原型阶段；正式版换持久化会话 / JWT）
const sessions = new Map();

function httpErr(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

function hash(password, salt) {
  return crypto.scryptSync(String(password), salt, 32).toString('hex');
}

function publicUser(u) {
  return {
    id: u.id, username: u.username, name: u.name,
    country: u.country, role: u.role, createdAt: u.createdAt,
  };
}

function createUser({ username, password, role, name, country }) {
  const users = readJSON(USERS_FILE, []);
  const uname = String(username || '').trim().toLowerCase();
  if (!uname) throw httpErr(400, '请输入用户名');
  if (users.some((u) => u.username === uname)) throw httpErr(409, '用户名已被占用');
  if (!password || String(password).length < 6) throw httpErr(400, '密码至少 6 位');

  const salt = crypto.randomBytes(8).toString('hex');
  const id = 'u-' + crypto.randomBytes(6).toString('hex');
  const user = {
    id,
    username: uname,
    name: String(name || uname).trim(),
    country: String(country || '').trim(),
    role: role === 'expert' ? 'expert' : 'creator',
    salt,
    passwordHash: hash(password, salt),
    createdAt: Date.now(),
  };
  users.push(user);
  writeJSON(USERS_FILE, users);
  return publicUser(user);
}

function verify(username, password) {
  const users = readJSON(USERS_FILE, []);
  const u = users.find((x) => x.username === String(username || '').trim().toLowerCase());
  if (!u || hash(password, u.salt) !== u.passwordHash) throw httpErr(401, '用户名或密码错误');
  return publicUser(u);
}

function issueSession(user) {
  const token = crypto.randomBytes(16).toString('hex');
  sessions.set(token, user.id);
  return token;
}

function resolveSession(token) {
  if (!token) return null;
  const uid = sessions.get(token);
  if (!uid) return null;
  const users = readJSON(USERS_FILE, []);
  const u = users.find((x) => x.id === uid);
  return u ? publicUser(u) : null;
}

function destroySession(token) {
  sessions.delete(token);
}

module.exports = { createUser, verify, issueSession, resolveSession, destroySession };
