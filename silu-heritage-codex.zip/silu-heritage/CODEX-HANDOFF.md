# Codex 续作说明

本压缩包为「丝路遗珍 · 数字文化遗产平台」的完整源码快照，供在新的 Codex 环境中继续开发。

## 一、快速启动

环境要求：Node.js ≥ 18（本地验证 v22）。

```bash
# 1. 安装依赖（node_modules 未打入包内，需重新安装）
npm install

# 2. 复制环境变量模板并填入真实密钥
cp .env.example .env

# 3. 启动
npm start
# 浏览器打开 http://localhost:3000
```

未填 `TRIPO_API_KEY` / `ARK_API_KEY` 时，后端自动进入 Mock 演示模式，不发起真实计费调用。

## 二、工程结构

```
silu-heritage/
├── .env.example          # 环境变量模板（真实 .env 未打入本包）
├── package.json / package-lock.json
├── Procfile / render.json # PaaS 启动与构建配置（备用）
├── README.md             # 方案、目录、API 映射、部署说明
├── server/
│   ├── index.js          # 静态站点 + JSON API 路由（原生 http，零运行时依赖）
│   ├── config.js         # 读取 .env，判断 Tripo / 方舟是否启用
│   ├── store.js         # JSON 文件读写，数据目录可用 DATA_DIR 覆盖
│   ├── data/             # assets.json 演示资产；users/models/posts 为本地持久化数据
│   └── adapters/         # auth / tripo / ark / http
└── public/
    ├── index.html / exhibit.html / studio.html / community.html / account.html
    ├── vendor/          # Three.js 本地构建与 addons（importmap 映射，勿删）
    ├── css/style.css
    └── js/               # common(i18n) / library / exhibit / studio / community / viewer
```

## 三、环境变量清单

| 变量 | 说明 |
| --- | --- |
| `PORT` | 服务端口，本地默认 3000；平台环境一般自动注入，勿写死 |
| `TRIPO_API_KEY` | Tripo 密钥，留空走 Mock |
| `TRIPO_BASE_URL` | 默认 `https://openapi.tripo3d.com/v3` |
| `TRIPO_MODEL` | Tripo 建模模型 ID |
| `ARK_API_KEY` | 火山方舟密钥，留空走 Mock |
| `ARK_BASE_URL` | 默认 `https://ark.cn-beijing.volces.com/api/v3` |
| `ARK_CHAT_MODEL` | 对话 / 讲解稿模型 |
| `ARK_TRANSLATION_MODEL` | 翻译模型 |
| `ARK_EMBEDDING_MODEL` | 向量化模型 |
| `ARK_VISION_MODEL` | 视觉理解模型，留空复用对话模型 |
| `ARK_MULTIVIEW_MODEL` | 图像生成 / 参考视图模型 |
| `DATA_DIR` | 持久化 JSON 目录，默认 `server/data` |

## 四、当前已知约束（续作时优先关注）

1. **持久化**：账号、工坊模型、论坛帖子写入 `server/data/*.json`；临时磁盘环境重启后回到文件内现有内容，长期留存需挂持久卷并设置 `DATA_DIR`。
2. **会话**：登录态为内存 Map，服务重启后全部失效，需重新登录。
3. **Tripo 票据链接**：历史 GLB 链接带有时效 `auth_key`，过期后不可直接复用；新生成任务以 Tripo 返回的新票据为准。
4. **方舟端点**：`ark.cn-beijing.volces.com` 为国内端点，从海外节点访问可能延迟或不通。
5. **前端 Three.js**：通过 `public/vendor` 本地 importmap 引用，不依赖 npm 包；`package.json` 中残留的 `three` 仅为历史依赖，服务端未 `require`。
6. **公网部署适配**：`server/index.js` 已绑定 `0.0.0.0`；密钥只走平台后台环境变量，切勿把真实 `.env` 提交到公开仓库。

## 五、待迭代方向（摘自 README）

- 部件标注与测量；拆解部件分组的持久化保存。
- 以图搜视频的视觉向量检索（当前按资产标签匹配预留 `imageUrl` 分支）。
- 会话持久化、专家审核流落库、创作者作品归属与云端对象存储。
- 文博专有名词多语翻译术语库。
