# 丝路遗珍 · 数字文化遗产平台

面向中国—东盟的多语种文化遗产数字资产共创平台原型。依据 `丝路遗珍 · 数字文化遗产平台.xmind` 信息架构搭建，对接 **Tripo AI（图生 3D 建模）** 与 **火山方舟 / 豆包大模型（翻译 · 视觉理解 · 搜索）**。

## 一、已确认的方案

| 项 | 当前方案 |
| --- | --- |
| 技术形态 | 原生 HTML/CSS/JS 前端 + Node 零依赖后端代理（后端代理用于隐藏 API Key） |
| API Key | `.env` 配置；未填 Key 时自动进入 **Mock 模式**（返回演示数据，不计费），填入即切换真实调用 |
| 语种 | 中文 / 英语 / 印尼语 / 马来语 / 泰语；点击某语言展签即联动切换整站语言 |
| 3D 预览 | Three.js（本地 vendor）+ OrbitControls + GLTFLoader；无 GLB 时显示占位器型，接入 Tripo 返回的 GLB 后真实加载 |
| 图片理解 | 豆包多模态视觉模型（识别器型、材质、纹饰、工艺判断） |
| 视频 | **不做 AI 生成短片**；检索用户上传图片后匹配已有影像，命中则播放，无匹配则隐藏播放器 |

## 二、目录结构

```
silu-heritage/
├── .env.example / .env          # API Key 与模型配置
├── package.json
├── server/
│   ├── index.js                  # 静态站点 + JSON API 路由（零依赖）
│   ├── config.js                 # 读取 .env，判断 Tripo / 方舟是否启用
│   ├── data/                  # assets.json 演示资产；users.json / models.json / posts.json 持久化数据
│   ├── store.js              # JSON 读写持久化
│   └── adapters/
│       ├── http.js                # fetch 封装（JSON / Buffer body）
│       ├── auth.js              # scrypt 加盐哈希 + 内存会话（注册 / 登录 / 校验）
│       ├── tripo.js              # 文件上传 / 单图生3D / 四视图生3D / 智能拆解 / 任务轮询（含 Mock）
│       └── ark.js                # 翻译 / 视觉理解 / 语义搜索 / 单张参考视图生成（含 Mock）
└── public/
    ├── index.html                # 数字非遗资产库（检索 + 筛选 + 卡片网格）
    ├── exhibit.html             # 文物拆装与技艺演示（整体 / 拆装 / 技艺 + 工坊模型列表）
    ├── studio.html              # 创作工坊（单图 / 四视图 / 单图生成参考视图 / 已有3D上传 / 视觉识别 / 视频检索）
    ├── community.html           # 共创社区论坛（登录发帖，可附工坊模型）
    ├── account.html             # 注册 / 登录 / 个人账号信息
    ├── vendor/                  # Three.js 本地构建与 addons（OrbitControls / GLTFLoader）
    ├── css/style.css
    └── js/                      # common(i18n) / library / exhibit / studio / community / viewer
```

## 三、运行方式

```bash
cd silu-heritage
npm start          # 等价于 node server/index.js
# 浏览器打开 http://localhost:3000
```

后端零依赖，Node ≥ 18。Three.js 已 vendor 到 `public/vendor`，前端无需构建。

## 四、API 对接映射

### Tripo AI（3D 建模，Base：`https://openapi.tripo3d.com/v3`）

| 平台功能 | 后端路由 | Tripo 接口 |
| --- | --- | --- |
| 图片上传换取 file_token | `POST /api/tripo/upload` | `POST /files`（multipart） |
| 单张图片生成 3D | `POST /api/tripo/image-to-model` | `POST /generation/image-to-model` |
| 四视图（前/左/后/右）生成 3D | `POST /api/tripo/multiview-to-model` | `POST /generation/multiview-to-model` |
| 智能拆解（部件分割） | `POST /api/tripo/segment` | `POST /mesh/segment`（默认 v1 几何分割，速度优先），输出分割后 GLB |
| 任务状态查询 | `GET /api/tripo/tasks/:id` | `GET /tasks/{task_id}` |

> 仅支持本地图片上传：前端转 base64 发给后端，后端组装 multipart 上传 Tripo 换取 `file_token`，不提供公网 URL 入口。
> 四视图 `inputs` 为 view-key 对象数组：`[{front}, {left}, {back}, {right}]`；正面必传，至少 2 张。
> 注意：Tripo 账户余额为 0 时，真实建模任务会返回余额不足错误（错误码 2010）；无 Key 时走 Mock 任务。
> 余额查询：`GET /v3/account/balance`；用量：`GET /v3/account/usage`。

### 火山方舟 / 豆包（Base：`https://ark.cn-beijing.volces.com/api/v3`）

| 平台功能 | 后端路由 | 方舟接口 / 模型 |
| --- | --- | --- |
| 多语展签翻译 | `POST /api/ark/translate` | Responses API（`/responses`，translation_options 指定源/目标语种）· 翻译模型 |
| 图片视觉理解 | `POST /api/ark/vision` | 多模态 Chat（image_url content） |
| 单图生成一张参考视图 | `POST /api/ark/multiview` | 方舟图像生成（`images/generations`），返回单张图片 URL，模型可由 `ARK_MULTIVIEW_MODEL` 覆盖 |
| 图片代理（保存到自选目录） | `GET /api/ark/proxy?url=` | 仅放行 `*.volces.com / *.tripo3d.com`，回传图片 Blob |
| 资产语义搜索 | `GET /api/ark/search?q=` | 多模态向量（`/embeddings/multimodal`）召回 + 关键词兜底 |
| 相关影像检索 | `GET /api/video/search?assetId=&imageUrl=` | 资产 / 图片匹配已有视频（无则返回 found=false） |

### 账户 / 工坊模型 / 论坛（本地持久化，`server/data/*.json`）

| 平台功能 | 后端路由 | 说明 |
| --- | --- | --- |
| 注册 | `POST /api/auth/register` | `{username,password,role,name,country}`，scrypt 加盐哈希；返回 `token` + `user` |
| 登录 | `POST /api/auth/login` | 校验密码，签发会话 token（内存会话，重启需重新登录） |
| 登出 | `POST /api/auth/logout` | 销毁当前会话 |
| 当前用户 | `GET /api/auth/me` | Bearer 校验；未登录返回 401 |
| 工坊模型列表 | `GET /api/models` | 工坊出模 / 上传 3D 后登记，演示页「工坊模型」区同步展示 |
| 登记模型 | `POST /api/models` | 登录后归属用户；未登录记为 `visitor` |
| 导出模型 | `GET /api/models/:id/download` | 代理远程 GLB 流式下载，`Content-Disposition` 附件；仅放行 `*.tripo3d.com` 地址 |
| 论坛帖子 | `GET /api/forum/posts` | 所有人可见，按时间倒序 |
| 发帖 | `POST /api/forum/posts` | 需登录；`{content, modelId}`，自动附带工坊模型标题 |

> 前端通过 `Authorization: Bearer <token>` 携带会话；账号、模型、帖子分别落库 `users.json / models.json / posts.json`。

## 五、接入真实 Key

编辑 `.env`：

```
TRIPO_API_KEY=你的Tripo密钥
ARK_API_KEY=你的方舟密钥
```

Key 留空即进入 Mock。`ARK_CHAT_MODEL / ARK_TRANSLATION_MODEL / ARK_VISION_MODEL / ARK_EMBEDDING_MODEL / ARK_MULTIVIEW_MODEL` 可替换为控制台模型 ID 或推理接入点 ID（`ep-xxxx`）。

## 六、部署到国外 PaaS（常驻公网）

技术形态为 Node 后端 + 本地静态资源，可直接部署到 Railway / Render 等支持常驻 Node 的平台；前端通过相对路径调用 `/api/*`，无需跨域配置。

### 上线前要点

- **密钥不进代码**：`.env` 已在 `.gitignore` 中排除；`TRIPO_API_KEY`、`ARK_API_KEY` 及各模型 ID 在平台后台的环境变量里逐项配置，`PORT` 由平台自动注入，不要写死。
- **种子数据**：`server/data/assets.json` 为内置演示资产；`users.json / models.json / posts.json` 部署包内重置为空数组。
- **文件持久化**：账号、工坊模型、帖子写入 `server/data/*.json`。PaaS 临时磁盘在重启 / 重新部署后会回到种子状态；需要长期留存时，挂载持久卷并设置环境变量 `DATA_DIR` 指向卷内目录。
- **免费实例限制**：Render Free 无访问约 15 分钟后休眠，首次访问冷启动；Railway 按额度计费。海外节点访问 `ark.cn-beijing.volces.com`（火山方舟国内端点）可能延迟或不通，Tripo openapi 为国际端点。
- **会话为内存 Map**：服务重启后所有登录态失效，需重新登录。

### 平台配置

- 启动命令：`node server/index.js`（`Procfile` / `render.json` 已内置；`package.json` 的 `npm start` 等价）。
- 构建命令：`npm install --omit=dev`。
- Node 版本：≥ 18（本地验证 v22）。

### 环境变量清单

| 变量 | 必填 | 说明 |
| --- | --- | --- |
| `TRIPO_API_KEY` | 否 | 留空进入 Tripo Mock 模式 |
| `TRIPO_BASE_URL` | 否 | 默认 `https://openapi.tripo3d.com/v3` |
| `TRIPO_MODEL` | 否 | Tripo 建模模型 |
| `ARK_API_KEY` | 否 | 留空进入方舟 Mock 模式 |
| `ARK_BASE_URL` | 否 | 默认 `https://ark.cn-beijing.volces.com/api/v3` |
| `ARK_CHAT_MODEL` | 否 | 对话 / 讲解稿模型 |
| `ARK_TRANSLATION_MODEL` | 否 | 翻译模型 |
| `ARK_EMBEDDING_MODEL` | 否 | 向量化模型 |
| `ARK_VISION_MODEL` | 否 | 留空复用对话模型 |
| `ARK_MULTIVIEW_MODEL` | 否 | 图像生成 / 参考视图模型 |
| `DATA_DIR` | 否 | 持久卷数据目录，默认 `server/data` |

## 七、待办 / 后续迭代

1. 部件标注与测量；拆解后部件分组的持久化保存（当前支持点选、箭头拖拽平移、两两合并、一键复位）。
2. 以图搜视频的视觉向量检索（当前按资产标签匹配预留 `imageUrl` 分支）。
3. 会话持久化（当前为内存会话）、专家角色审核流落库、创作者作品归属与云端对象存储。
4. 术语库文件：约束文博专有名词的多语翻译一致性。
5. 方舟控制台开通对话 / 翻译 / 视觉 / 向量模型，或在 `.env` 中填入已开通的推理接入点 ID（`ep-xxxx`）。
